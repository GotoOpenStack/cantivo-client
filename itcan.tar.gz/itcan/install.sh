#!/bin/sh

sh scripts/virt.sh
sh scripts/web.sh
sh scripts/redis.sh
sh scripts/phplibvirt.sh
sh scripts/daemons.sh
cat etc/sysctl.conf >> /etc/sysctl.conf
sh scripts/network.sh

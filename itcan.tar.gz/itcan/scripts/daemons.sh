#!/bin/bash

yum -y install screen fping
echo "sleep 2" >> /etc/rc.local
echo "screen -dmS v2rcpu sh /var/www/html/scripts/v2rcpu.sh" >> /etc/rc.local
echo "screen -dmS v2rnet sh /var/www/html/scripts/v2rnet.sh" >> /etc/rc.local




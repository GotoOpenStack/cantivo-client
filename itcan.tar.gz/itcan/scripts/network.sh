#!/bin/bash

#we need this
yum -y install bridge-utils

#copy network config stuff 
cp etc/ifcfg-br0 /etc/sysconfig/network-scripts/
cp etc/ifcfg-eth0 /etc/sysconfig/network-scripts/
#cp etc/ifcfg-br1 /etc/sysconfig/network-scripts/
#cp etc/ifcfg-eth1 /etc/sysconfig/network-scripts/

#issue (purely cosmetic)
cp etc/issue /etc/
cp etc/issue.net /etc/

#Disable NetworkManager
chkconfig --level 345 NetworkManager off
service NetworkManager stop

#Enable network
chkconfig --level 345 network on
service network start

#Disable firewall (again)
chkconfig ip6tables off
chkconfig iptables off
service ip6tables stop
service iptables stop

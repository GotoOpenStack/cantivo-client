#!/bin/bash

# hm not sure we need these anymore
#rpm --import http://www.jasonlitka.com/media/RPM-GPG-KEY-jlitka
#cp etc/utterramblings.repo /etc/yum.repos.d/
#yum -y upgrade

yum -y install php-devel php-mbstring php-mhash php-pear

pushd src/ && tar zxfv php-libvirt* && cd php-libvirt* && phpize && ./configure && make && make install && popd

cp etc/php.d/libvirt.ini /etc/php.d/
cp etc/php.ini /etc/

service httpd restart


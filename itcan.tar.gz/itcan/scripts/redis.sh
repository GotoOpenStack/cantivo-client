#!/bin/bash

yum -y install make gcc

pushd src/ && tar zxfv redis-* && cd redis-* && make
cp redis-server /usr/local/bin/
cp redis-cli /usr/local/bin/
cp redis-benchmark /usr/local/bin/
cp ../../etc/redis.conf /etc/
mkdir -p /var/db/redis
echo "/usr/local/bin/redis-server /etc/redis.conf" >> /etc/rc.local
/usr/local/bin/redis-server /etc/redis.conf
popd



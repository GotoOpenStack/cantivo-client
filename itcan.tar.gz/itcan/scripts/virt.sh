#!/bin/bash

yum -y install kvm kvm-tools kvm-qemu-img qspice

ln -s /usr/libexec/qemu-kvm /usr/bin/qemu-kvm

# hmm not sure we need these anymore...
#rpm --import http://dag.wieers.com/rpm/packages/RPM-GPG-KEY.dag.txt
#yum -y install RPMS/rpmforge*

yum -y --nogpgcheck localinstall RPMS/*.rpm

chkconfig libvirtd on
service libvirtd restart

cp etc/libvirt/libvirtd.conf /etc/libvirt/
cp etc/libvirt/passwd.db /etc/libvirt/
service libvirtd restart

#!/bin/bash

yum -y install httpd php-devel php-gd php-cli php-mcrypt php-mhash php-xml php-common

chkconfig httpd on

mkdir /nfs
mkdir /vm
mkdir /iso
mkdir /upload
chmod 777 /upload

cp etc/httpd.conf /etc/httpd/conf/

cp etc/selinux/config /etc/selinux/


rsync -ra --progress www/ /var/www/html/

chown -R apache:apache /var/www/html/
chmod -R 755 /var/www/html/

service httpd start

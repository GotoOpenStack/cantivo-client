<?php
$timer_start = microtime(true);
if(substr_count($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip')) {
 ob_start("ob_gzhandler");
} else {
 ob_start();
}

include("lib/config.php");

include("theme2/header.php");


if(isset($_POST["username"])) {

$a = new auth();

if($a->login($_POST["username"],$_POST["password"])) {
print "<br/><br/><br/><center><span style='color: green;'>login success!</span></center><br/><br/><br/><br/>";
$world->goto("home");

} else {

//if($a->adduser($_POST["username"],$_POST["password"])) print "add ok!";

print "authentication failed!";
}
}




if($_GET["m"] == "") { 
include("mod/login/main.php");
}

elseif(isset($_GET["m"])) {
	if(file_exists("mod/".$_GET["m"]."/main.php")) include("mod/".$_GET["m"]."/main.php");
}

include("theme2/footer.php");

ob_end_flush();
?>
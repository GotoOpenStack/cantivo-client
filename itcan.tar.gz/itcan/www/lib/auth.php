<?php

class auth {

	function __construct() {
		if(!$this->getall()) $this->adduser("admin","admin");
	}


	function adduser($username,$password) {
		$configurations = array(
    	'host'     => '127.0.0.1', 
    	'port'     => 6379, 
    	'database' => 1
		);
		$redis = Predis_Client::create($configurations);
   
   		if($redis->set("user:".$username, md5($password))) return true;
	
	}


	function login($username,$password) {
		
		$configurations = array(
    	'host'     => '127.0.0.1', 
    	'port'     => 6379, 
    	'database' => 1
		);
		$redis = Predis_Client::create($configurations);

		if(md5($password) == $redis->get("user:".$username)) return true;
		return false;
	}
	
	function getall() {
	
		$configurations = array(
    	'host'     => '127.0.0.1', 
    	'port'     => 6379, 
    	'database' => 1
		);
		$redis = Predis_Client::create($configurations);
		$all = $redis->keys("user:*");
		if(!count($all)) return false;
		return $all;
	}

}
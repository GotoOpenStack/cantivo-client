<?php

class bootvm {

	var $key;
	
	var $ip;
	var $user;
	
	var $reg;	// registered in db
	var $auth;	// ssh pub key authorization is complete
	
	var $redis_conf = array(
    	'host'     => '127.0.0.1', 
    	'port'     => 6379, 
    	'database' => 1
	);
	
	public function __construct($key=false) {
		if(isset($key)) $this->load($key);
	}
	
	public function load($key) {
		$redis = Predis_Client::create($this->redis_conf);
		$this->ip = $redis->get("bootvm:".$key.":ip");
		$this->user = $redis->get("bootvm:".$key.":user");
		$this->reg = $redis->get("bootvm:".$key.":reg");
		$this->auth = $redis->get("bootvm:".$key.":auth");
		return $this->reg;
	}
	
	public function save($user,$ip) {
		$redis = Predis_Client::create($this->redis_conf);
		$this->key = md5($user.$ip);
		$redis->set("bootvm:".$this->key.":ip", $ip);
		$redis->set("bootvm:".$this->key.":user", $user);
		$redis->set("bootvm:".$this->key.":reg", 1);
		$redis->set("bootvm:".$this->key.":auth", 1);
		return $this->key;
	}
	
	public function getkeybyip($ip) {
		$redis = Predis_Client::create($this->redis_conf);
		
		foreach($redis->keys("bootvm:*:ip") as $v) {
			$x = explode(":",$v);
			$iip = $redis->get($v);
			if($ip == $iip) return $x[1];
		}
		return false;
	}
	
	public function getall() {
		$redis = Predis_Client::create($this->redis_conf);
		$ret = array();
		foreach($redis->keys("bootvm:*:ip") as $v) {
			$x = explode(":",$v);
			$ret[] = $x[1];
		}
		return $ret;
	}
	
}
<?php

class cli {


	function __construct() {
	
	}
	
	function ex($arg) {
			
		$x = explode(" ", $arg);
		if(count($x)>1) {
			
			$f = "exec".$x[0];
			if(function_exists($this->$f)) $this->$f($x[1],$x[2],$x[3]);
			
		} else {
		
			$f = "exec".$arg;
			$this->$f();
			if(function_exists($this->$f)) {
			print "yo3".$f."  "; 
			}
		}
	}
	
	function execpwd() {
		print "yo2";
		$x = exec("pwd", $out);
		print $out[0];
	}
	
	function execls($arg=false) {
		print "yo2";
			
		if(!$arg) $x = exec("ls -lah", $out);
		$x = exec("ls -lah ".$arg, $out);
		print_R($out);
	}
}
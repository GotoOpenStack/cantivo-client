<?php


class world {

	var $name = "itcan beta";
	var $ver = "0.3";
	
	
	
	
	public function goto($where) {
		$host  = $_SERVER['HTTP_HOST'];
        $uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
        print '<meta http-equiv="refresh" content="0;url='.$uri.'/'.$where.'" />';
        exit();
	}
}

include_once("lib/predis.php");
include_once("lib/libvirt.php");
include_once("lib/auth.php");
include_once("lib/nfs.php");
include_once("lib/cli.php");
include_once("lib/bootvm.php");
$world = new world();
<?php


class libvirt {

	var $conn;
	var $uri = "qemu:///system";
	var $credentials = array(VIR_CRED_AUTHNAME=>"root",VIR_CRED_PASSPHRASE=>"n1ntend0");
	
	var $dom;
	
	var $domains = array();
	
	var $uuid;
	var $name;
	
	public function __construct($uuid=false) {
	
		if(isset($uuid)) { 
			$this->uuid = $uuid;
			$this->connect();
			
			$this->select_dom_by_uuid($uuid);
			
		}
	}
	
	public function connect() {
		$this->conn=libvirt_connect($this->uri,false,$this->credentials);
		if ($this->conn==false)
		{
    		echo ("Libvirt last error: ".libvirt_get_last_error()."\n");
    		exit;
		}
	}
	
	public function select_dom_by_uuid($uuid) {	
		$this->dom = libvirt_domain_lookup_by_uuid_string($this->conn,$uuid);
	}
	
	public function domain_interface_stats($interface) {
		if($interface != "") return libvirt_domain_interface_stats($this->dom, $interface);
		return false;
	}
	
	public function domain_memory_stats() {
		return libvirt_domain_memory_stats($this->dom);
	}
	
	public function domain_get_uuid_string() {
		return libvirt_domain_get_uuid_string($this->dom);
	}
	
	public function domain_get_info() {
		return libvirt_domain_get_info($this->dom);
	}
	
	public function domain_get_name() {
		return libvirt_domain_get_name($this->dom);	
	}

	public function get_hostname() {
		return libvirt_get_hostname($this->conn);
	}
	
	public function node_get_info() {
		return libvirt_node_get_info($this->conn);
	}
	
	public function list_domains() {
		$this->domains=libvirt_list_domains($this->conn);
	}
	
	public function suspend() {
		libvirt_domain_suspend($this->dom);
	}

	public function pause() {
		$this->suspend();
	}

	public function resume() {
		libvirt_domain_resume($this->dom);
	}

	public function start() {
		libvirt_domain_create($this->dom);
	}

	public function shutdown() {
		libvirt_domain_shutdown($this->dom);
	}

	public function destroy() {
		libvirt_domain_destroy($this->dom);
	}
	public function reboot() {
		libvirt_domain_reboot($this->dom);
	}
	
	public function domain_get_xml_desc() {
		return libvirt_domain_get_xml_desc($this->dom);
	}
	
	
	// BUTT UGLY, NEEDS TO BE REPLACED WITH PROPER XML PARSER LOGIC
	public function parsexmldom($xml) {
	
		$ret = array(); //return array

		// FIND MAC ADDRESS
		$mac_x = explode("mac address='",$xml);
        $mac_xx = explode("'",$mac_x[1]);
        $ret["mac"] = strtoupper($mac_xx[0]);
		
		
		// FIND IP ADDRESS (USING MAC)
		if(isset($ret["mac"]) && $ret["mac"] != "") {
		
			$ret["ip"] = $this->ip_from_mac($ret["mac"]);
		} 
		
		
		return $ret;

	}
	public function ip_from_mac($mac) {
		$vm_ip = exec("/sbin/arp -a -n|grep '".trim($mac)."'");
        if($vm_ip != "") {
			$xx = explode("(",$vm_ip);
			$xxx = explode(")",$xx[1]);
			
			return $xxx[0];
		} 
		return "0.0.0.0";
	}
	
	

	
	public function qemu_img_info($file,$check_lsof=false) {
		
		if(file_exists($file)) {
		
			$ex = exec("qemu-img info ".$file, $out);
						
			$ret = array();
			
			if(isset($out[1])) {
			$fmt = explode(":",$out[1]);
			$ret["format"] = trim($fmt[1]);
			}
			
			if(isset($out[2])) {
			$vsize = explode(":", $out[2]);
			$vsize_0 = explode("(", $vsize[1]);
			$ret["vsize"] = trim($vsize_0[0]);
			}
			
			if(isset($out[3])) {
			$dsize = explode(":", $out[3]);
			$ret["dsize"] = trim($dsize[1]);
			}
			
			if(isset($out[4])) {
			$csize = explode(":", $out[4]);
			$ret["csize"] = trim($csize[1]);
			}
			
			//OVERLAY?
			if(isset($out[5]) && $out[5] != "") {
			$ovl = explode(":", $out[5]);
			$ovl_1 = explode("(",$ovl[1]);
			$ret["overlay"] = trim($ovl_1[0]);
			}	
			
			//IS FILE IN USE?
			if($check_lsof) {
			$cmd = shell_exec('/usr/sbin/lsof|grep "'.$file.'"');
			if(count($ret)) {
				$ret["lock"] = $cmd;
			}
			}
			
			return $ret;
		}
	}
	
	public function improved_parsexmldom($xml) {
		
		$arr = ToArray(simplexml_load_string($xml));
		//print_r($arr);
		
		$dom = new dom();
		$dom->type = $arr["@attributes"]["type"];
		$dom->name = $arr["name"];
		$dom->uuid = $arr["uuid"];
		$dom->memory = $arr["memory"];
		$dom->currentMemory = $arr["currentMemory"];
		$dom->vcpu = $arr["vcpu"];
		
		$dom->os_type = $arr["os"]["type"];
		//$dom->os_machine = $arr["os"]["@attributes"]["machine"];
		//$dom->os_arch = $arr["os"]["@attributes"]["arch"];
		
		$dom->clock_offset = $arr["clock"]["@attributes"]["offset"];
		$dom->on_poweroff = $arr["on_poweroff"];
		$dom->on_reboot = $arr["on_reboot"];
		$dom->on_crash = $arr["on_crash"];
		
		
		//print_r($arr["os"]["boot"]);
		if(isset($arr["os"]["boot"]["@attributes"]["dev"])) $dom->boot_dev = $arr["os"]["boot"]["@attributes"]["dev"];
		if(isset($arr["devices"]["emulator"])) $dom->emulator = $arr["devices"]["emulator"];
		
		if(isset($arr["features"]["pae"])) $dom->feature_pae = true;
		if(isset($arr["features"]["apic"])) $dom->feature_apic = true;
		if(isset($arr["features"]["acpi"])) $dom->feature_acpi = true;
		
		
		$dom->graphics_type = $arr["devices"]["graphics"]["@attributes"]["type"];
		$dom->graphics_port = $arr["devices"]["graphics"]["@attributes"]["port"];
		if(isset($arr["devices"]["graphics"]["@attributes"]["autoport"])) $dom->graphics_autoport = $arr["devices"]["graphics"]["@attributes"]["autoport"];
		if(isset($arr["devices"]["graphics"]["@attributes"]["listen"]))$dom->graphics_listen = $arr["devices"]["graphics"]["@attributes"]["listen"];
		if(isset($arr["devices"]["graphics"]["@attributes"]["keymap"])) $dom->graphics_keymap = $arr["devices"]["graphics"]["@attributes"]["keymap"];
		
		// DO WE HAVE MORE THAN ONE DISK?
		if(isset($arr["devices"]["disk"]["1"])) {
			//YES
			foreach($arr["devices"]["disk"] as $disk) {
			
				/*$temp_disk = new disk();
				$temp_disk->type = $disk["@attributes"]["device"];
				$temp_disk->device = $disk["target"]["@attributes"]["dev"];
				$temp_disk->source = $disk["source"]["@attributes"]["file"];
				$temp_disk->bus = $disk["target"]["@attributes"]["bus"];
				$temp_disk->driver = $disk["driver"]["@attributes"]["name"];
				if(isset($disk["readonly"])) $temp_disk->readonly = true;
				$dom->disk[] = $temp_disk;
				*/
				
				$temp_disk = array();
				$temp_disk["type"] = $disk["@attributes"]["device"];
				$temp_disk["device"] = $disk["target"]["@attributes"]["dev"];
				if(isset($disk["source"]["@attributes"]["file"])) $temp_disk["source"] = $disk["source"]["@attributes"]["file"];
				
				$temp_disk["bus"] = $disk["target"]["@attributes"]["bus"];
				
				if(isset($disk["driver"]["@attributes"]["name"])) $temp_disk["driver"] = $disk["driver"]["@attributes"]["name"];
				if(isset($disk["readonly"])) $temp_disk["readonly"] = "true";
			
				//print_r($temp_disk);
				$dom->disk[] = $temp_disk;


			}
			
		} else {
			// NO, JUST ADD ONE:
			/*$temp_disk = new disk();
			$temp_disk->type = $arr["devices"]["disk"]["@attributes"]["device"];
			$temp_disk->device = $arr["devices"]["disk"]["target"]["@attributes"]["dev"];
			$temp_disk->source = $arr["devices"]["disk"]["source"]["@attributes"]["file"];
			$temp_disk->bus = $arr["devices"]["disk"]["target"]["@attributes"]["bus"];
			$temp_disk->driver = $arr["devices"]["disk"]["driver"]["@attributes"]["name"];
			if(isset($disk["devices"]["disk"]["readonly"])) $temp_disk->readonly = true;
			$dom->disk = $temp_disk;
			*/
			
			$temp_disk = array();
			$temp_disk["type"] = $arr["devices"]["disk"]["@attributes"]["device"];
			$temp_disk["device"] = $arr["devices"]["disk"]["target"]["@attributes"]["dev"];
			if(isset($arr["devices"]["disk"]["source"]["@attributes"]["file"])) $temp_disk["source"] = $arr["devices"]["disk"]["source"]["@attributes"]["file"];
			$temp_disk["bus"] = $arr["devices"]["disk"]["target"]["@attributes"]["bus"];
			$temp_disk["driver"] = $arr["devices"]["disk"]["driver"]["@attributes"]["name"];
			if(isset($disk["devices"]["disk"]["readonly"])) $temp_disk["readonly"] = "true";
				
			$dom->disk[] = $temp_disk;
	
		
		}
		
		
		// MORE THAN ONE NETDEV?
		if(!isset($arr["devices"]["interface"]["1"])) {
		
				/*$temp_net = new netdev();
				$temp_net->type = $arr["devices"]["interface"]["@attributes"]["type"];
				$temp_net->mac = $arr["devices"]["interface"]["mac"]["@attributes"]["address"];
				if(isset($arr["devices"]["interface"]["target"]["@attributes"]["dev"])) $temp_net->target = $arr["devices"]["interface"]["target"]["@attributes"]["dev"];
				$temp_net->model = $arr["devices"]["interface"]["model"]["@attributes"]["type"];
				
				$dom->netdev[] = $temp_net;
				*/

				$temp_net = array();
				$temp_net["type"] = $arr["devices"]["interface"]["@attributes"]["type"];
				$temp_net["mac"] =  strtoupper($arr["devices"]["interface"]["mac"]["@attributes"]["address"]);
				if(isset($arr["devices"]["interface"]["target"]["@attributes"]["dev"])) $temp_net["target"] = $arr["devices"]["interface"]["target"]["@attributes"]["dev"];
				if(isset($arr["devices"]["interface"]["model"]["@attributes"]["type"])) {
				 $temp_net["model"] = $arr["devices"]["interface"]["model"]["@attributes"]["type"];
				} else {
					$temp_net["model"] = "default";
				}
				
				$dom->netdev[] = $temp_net;


		} else {
		// YES
				foreach($arr["devices"]["interface"] as $i) {

					/*$temp_net = new netdev();
					$temp_net->type = $i["@attributes"]["type"];
					$temp_net->mac = $i["mac"]["@attributes"]["address"];
					if(isset($i["target"]["@attributes"]["dev"])) $temp_net->target = $arr["target"]["@attributes"]["dev"];
					$temp_net->model = $i["model"]["@attributes"]["type"];
				
					$dom->netdev = $temp_net;
					*/
					
					$temp_net = array();
					$temp_net["type"] = $i["@attributes"]["type"];
					$temp_net["mac"] = strtoupper($i["mac"]["@attributes"]["address"]);
					if(isset($i["target"]["@attributes"]["dev"])) $temp_net["target"] = $i["target"]["@attributes"]["dev"];
					$temp_net["model"] = $i["model"]["@attributes"]["type"];

					$dom->netdev[] = $temp_net;



				}
		}
		$dom->disk = array_reverse($dom->disk);
		$dom->netdev = array_reverse($dom->netdev);
		
		//print_r($dom);
		return $dom;
	}
			
	public function new_parsexmldom($xml) {	

		//print_r($xml);
		$arr = ToArray(simplexml_load_string($xml));
		print_r($arr);
		
		//$sxml = simplexml_load_string($xml);
  		//if (is_object($sxml)) $sxml = get_object_vars($sxml);
  		//$arr = (is_array($sxml)) ? array_map(__FUNCTION__,$sxml) : $sxml;


		$ret = "";
		
		$dom = new dom();
		$dom->type = $arr["@attributes"]["type"];
		$dom->name = $arr["name"];
		$dom->uuid = $arr["uuid"];
		$dom->memory = $arr["memory"];
		$dom->currentMemory = $arr["currentMemory"];
		$dom->vcpu = $arr["vcpu"];
		
		$dom->os_type = $arr["os"]["type"];
		//$dom->os_machine = $arr["os"]["@attributes"]["machine"];
		//$dom->os_arch = $arr["os"]["@attributes"]["arch"];
		
		$dom->clock_offset = $arr["clock"]["@attributes"]["offset"];
		$dom->on_poweroff = $arr["on_poweroff"];
		$dom->on_reboot = $arr["on_reboot"];
		$dom->on_crash = $arr["on_crash"];
		
		$dom->boot_dev = $arr["os"]["boot"]["@attributes"]["dev"];
		$dom->emulator = $arr["devices"]["emulator"];
		
		if(isset($arr["features"]["pae"])) $dom->feature_pae = true;
		if(isset($arr["features"]["apic"])) $dom->feature_apic = true;
		if(isset($arr["features"]["acpi"])) $dom->feature_acpi = true;
		
		
		$dom->graphics_type = $arr["devices"]["graphics"]["@attributes"]["type"];
		$dom->graphics_port = $arr["devices"]["graphics"]["@attributes"]["port"];
		$dom->graphics_listen = $arr["devices"]["graphics"]["@attributes"]["listen"];
		if(isset($arr["devices"]["graphics"]["@attributes"]["autoport"])) $dom->graphics_autoport = $arr["devices"]["graphics"]["@attributes"]["autoport"];
		if(isset($arr["devices"]["graphics"]["@attributes"]["keymap"])) $dom->graphics_keymap = $arr["devices"]["graphics"]["@attributes"]["keymap"];
		
		// DO WE HAVE MORE THAN ONE DISK?
		if(isset($arr["devices"]["disk"]["1"])) {
			//YES
			foreach($arr["devices"]["disk"] as $disk) {
			
			
				/*$temp_disk = new disk();
				$temp_disk->type = $disk["@attributes"]["device"];
				$temp_disk->device = $disk["target"]["@attributes"]["dev"];
				$temp_disk->source = $disk["source"]["@attributes"]["file"];
				$temp_disk->bus = $disk["target"]["@attributes"]["bus"];
				$temp_disk->driver = $disk["driver"]["@attributes"]["name"];
				if(isset($disk["readonly"])) $temp_disk->readonly = true;
				*/
			
				$temp_disk = array();
				$temp_disk["type"] = $disk["@attributes"]["device"];
				$temp_disk["device"] = $disk["target"]["@attributes"]["dev"];
				$temp_disk["source"] = $disk["source"]["@attributes"]["file"];
				$temp_disk["bus"] = $disk["target"]["@attributes"]["bus"];
				$temp_disk["driver"] = $disk["driver"]["@attributes"]["name"];
				if(isset($disk["readonly"])) $temp_disk["readonly"] = "true";
			
				$dom->disk[] = $temp_disk;

			}
			
		} else {
		
			// NO, JUST ADD ONE:
			/*$temp_disk = new disk();
			$temp_disk->type = $arr["devices"]["disk"]["@attributes"]["device"];
			$temp_disk->device = $arr["devices"]["disk"]["target"]["@attributes"]["dev"];
			$temp_disk->source = $arr["devices"]["disk"]["source"]["@attributes"]["file"];
			$temp_disk->bus = $arr["devices"]["disk"]["target"]["@attributes"]["bus"];
			$temp_disk->driver = $arr["devices"]["disk"]["driver"]["@attributes"]["name"];
			if(isset($disk["devices"]["disk"]["readonly"])) $temp_disk->readonly = true;
			*/
			
			$temp_disk = array();
			$temp_disk["type"] = $arr["devices"]["disk"]["@attributes"]["device"];
			$temp_disk["device"] = $arr["devices"]["disk"]["target"]["@attributes"]["dev"];
			$temp_disk["source"] = $arr["devices"]["disk"]["source"]["@attributes"]["file"];
			$temp_disk["bus"] = $arr["devices"]["disk"]["target"]["@attributes"]["bus"];
			$temp_disk["driver"] = $arr["devices"]["disk"]["driver"]["@attributes"]["name"];
			if(isset($disk["devices"]["disk"]["readonly"])) $temp_disk["readonly"] = "true";
				
			$dom->disk[] = $temp_disk;
		
		}
		
		
		// MORE THAN ONE NETDEV?
		if(!isset($arr["devices"]["interface"]["1"])) {
		
				/*$temp_net = new netdev();
				$temp_net->type = $arr["devices"]["interface"]["@attributes"]["type"];
				$temp_net->mac = $arr["devices"]["interface"]["mac"]["@attributes"]["address"];
				if(isset($arr["devices"]["interface"]["target"]["@attributes"]["dev"])) $temp_net->target = $arr["devices"]["interface"]["target"]["@attributes"]["dev"];
				$temp_net->model = $arr["devices"]["interface"]["model"]["@attributes"]["type"];
				*/
				
				$temp_net = array();
				$temp_net["type"] = $arr["devices"]["interface"]["@attributes"]["type"];
				$temp_net["mac"] =  $arr["devices"]["interface"]["mac"]["@attributes"]["address"];
				if(isset($arr["devices"]["interface"]["target"]["@attributes"]["dev"])) $temp_net["target"] = $arr["devices"]["interface"]["target"]["@attributes"]["dev"];
				$temp_net["model"] = $arr["devices"]["interface"]["model"]["@attributes"]["type"];
				
				$dom->netdev[] = $temp_net;
				
		} else {
		// NO
				foreach($arr["devices"]["interface"] as $i) {

					/*$temp_net = new netdev();
					$temp_net->type = $i["@attributes"]["type"];
					$temp_net->mac = $i["mac"]["@attributes"]["address"];
					if(isset($i["target"]["@attributes"]["dev"])) $temp_net->target = $i["target"]["@attributes"]["dev"];
					$temp_net->model = $i["model"]["@attributes"]["type"];
					*/
					
					$temp_net = array();
					$temp_net["type"] =
					$temp_net["mac"] = $i["mac"]["@attributes"]["address"];
					if(isset($i["target"]["@attributes"]["dev"])) $temp_net["target"] = $i["target"]["@attributes"]["dev"];
					$temp_net["mode"] = $i["model"]["@attributes"]["type"];

					$dom->netdev[] = $temp_net;

				}
		}
		print_r($dom);
			


		$verbose = 1;
		
		if($verbose) {
		// IDENTIFY WHICH ONE
		$ret .= "######################\n";
		$ret .= "### ".$arr["name"]."\n";
		$ret .= "###\n";
		//print_r($arr);
		
		
		// DISKS
		$ret .= "### HARD DISK(s)\n";
		
		
		$ret .= "BOOT: ".$arr["os"]["boot"]["@attributes"]["dev"]."\n";
		$ret .= "#\n";
		
		$disk_n=1;
		
		// CHECK IF ONE OR MORE NETDEVS?
		if(!isset($arr["devices"]["interface"]["1"])) {
		
		$ret .= "### INTERFACE-1\n";
		$ret .= "TYPE: ".$arr["devices"]["interface"]["@attributes"]["type"]."\n";
		$ret .= "MAC: ".$arr["devices"]["interface"]["mac"]["@attributes"]["address"]."\n";
		if(isset($arr["devices"]["interface"]["target"]["@attributes"]["dev"])) $ret .= "DEV: ".$arr["devices"]["interface"]["target"]["@attributes"]["dev"]."\n";
		$ret .= "MODEL: ".$arr["devices"]["interface"]["model"]["@attributes"]["type"]."\n";
		$ret .= "### \n";
		
		} else {
			$devs=1;
			foreach($arr["devices"]["interface"] as $i) {
				
				$ret .= "### INTERFACE-".$devs."\n";
				$ret .= "TYPE: ".$i["@attributes"]["type"]."\n";
				$ret .= "MAC: ".$i["mac"]["@attributes"]["address"]."\n";
				if(isset($i["target"]["@attributes"]["dev"])) $ret .= "DEV: ".$i["target"]["@attributes"]["dev"]."\n";
				$ret .= "MODEL: ".$i["model"]["@attributes"]["type"]."\n";
				$ret .= "### \n";
				//print_r($i);
				$devs++;
			}
		
		}



		if(!isset($arr["devices"]["disk"]["0"])) {
		// ONE DISK
		
			$ret .= "### HD-1\n";
			$ret .= "TYPE: ".$arr["devices"]["disk"]["@attributes"]["device"]."\n";
			$ret .= "TARGET: ".$arr["devices"]["disk"]["target"]["@attributes"]["dev"]."\n";
			if(isset($arr["devices"]["disk"]["source"]["@attributes"]["file"])) $ret .= "SOURCE: ".$arr["devices"]["disk"]["source"]["@attributes"]["file"]."\n";
			
			
			if(file_exists($arr["devices"]["disk"]["source"]["@attributes"]["file"])) {
			//$size = explode("	",@exec("du -h -c ".$disk["source"]["@attributes"]["file"]));
			$e = exec("du -h -c ".$arr["devices"]["disk"]["source"]["@attributes"]["file"], $o);
			$ee = explode("	",$o[0]);
			$size = $ee[0];
			
			$qinfo = $this->qemu_img_info($arr["devices"]["disk"]["source"]["@attributes"]["file"]);
			$ret .= "VSIZE: ".$qinfo["vsize"]."\n";
			if(isset($qinfo["overlay"])) $ret .= "OVERLAY OF: ".$qinfo["overlay"]."\n";
			
			} else {
			$size = "WARNING: ".$arr["devices"]["disk"]["source"]["@attributes"]["file"]." MISSING !";
			}
			
			$ret .= "SIZE: ".$size."\n";
			
			$ret .= "###\n";
			unset($o);
		
		} else {
		//MANY DISK
		foreach($arr["devices"]["disk"] as $disk) {
		
			$ret .= "### HD-".$disk_n."\n";
			$ret .= "TYPE: ".$disk["@attributes"]["device"]."\n";
			$ret .= "TARGET: ".$disk["target"]["@attributes"]["dev"]."\n";
			if(isset($disk["source"]["@attributes"]["file"]) && trim($disk["source"]["@attributes"]["file"]) != "") { 
			
				$ret .= "SOURCE: ".$disk["source"]["@attributes"]["file"]."\n";
			
			
			if(file_exists($disk["source"]["@attributes"]["file"])) {
			//$size = explode("	",@exec("du -h -c ".$disk["source"]["@attributes"]["file"]));
			$e = exec("du -h -c ".$disk["source"]["@attributes"]["file"], $o);
			$ee = explode("	",$o[0]);
			$size = $ee[0];
			
			$qinfo = $this->qemu_img_info($disk["source"]["@attributes"]["file"]);
			$ret .= "VSIZE: ".$qinfo["vsize"]."\n";
			if(isset($qinfo["overlay"])) $ret .= "OVERLAY OF: ".$qinfo["overlay"]."\n";
			
			
			} else {
			$size = "WARNING: ".$disk["source"]["@attributes"]["file"]." MISSING !";
			}
			$ret .= "SIZE: ".$size."\n";
			}
			
			$ret .= "###\n";
			
			
			$disk_n++;
			unset($o);
		}
		}

		// CHECK GRAPHICS
		$ret .= "### GRAPHICS\n";
		$ret .= "TYPE: ".$arr["devices"]["graphics"]["@attributes"]["type"]."\n";

		$ret .= "PORT: ".$arr["devices"]["graphics"]["@attributes"]["port"]."\n";

		if(isset($arr["devices"]["graphics"]["@attributes"]["autoport"])) $ret .= "AUTOPORT: ".$arr["devices"]["graphics"]["@attributes"]["autoport"]."\n";

		$ret .= "LISTEN: ".$arr["devices"]["graphics"]["@attributes"]["listen"]."\n";

		if(isset($arr["devices"]["graphics"]["@attributes"]["keymap"])) $ret .= "KEYMAP: ".$arr["devices"]["graphics"]["@attributes"]["keymap"]."\n";

		
				
		
		}
		return $ret;	
		//return $dom;
		
		
	}
	
	
	
}

/*
Cast object to array
*/
function ToArray($data)
{
	if (is_object($data)) $data = get_object_vars($data);
 	return (is_array($data)) ? array_map(__FUNCTION__,$data) : $data;
}
	
/*
Returns a human readable size
*/
function bytes($size){
  $i=0;
  $iec = array("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB");
  while (($size/1024)>1) {
   $size=$size/1024;
   $i++;
  }
return number_format($size,1,".",".")." ".$iec[$i];
//  return substr($size,0,strpos($size,'.'))." ".$iec[$i];
}

/*
Returns a human readable speed (bits/s)
*/
function bits($size){
  $i=0;
  $iec = array("bit/s", "Kbit/s", "Mbit/s", "Gbit/s", "Tbit/s", "Pbit/s", "Ebit/s", "Zbit/s", "Ybit/s");
  while (($size/1000)>1) {
   $size=$size/1000;
   $i++;
  }
return number_format($size*8,1,".","")." ".$iec[$i];
//  return substr($size,0,strpos($size,'.'))." ".$iec[$i];
}


class dom {
	var $type;
	var $name;
	var $uuid;
	var $memory;
	var $currentMemory;
	var $vcpu;
	var $os_type;
	var $os_arch;
	var $os_machine;
	var $boot_dev;
	var $feature_acpi=false;
	var $feature_apic=false;
	var $feature_pae=false;
	var $clock_offset;
	var $emulator;
	var $on_poweroff;
	var $on_reboot;
	var $on_crash;
	var $graphics_type;
	var $graphics_port=false;
	var $graphics_autoport=false;
	var $graphics_listen;
	var $graphics_keymap;
	var $netdev = array();
	var $disk = array();
}

class netdev {
	var $type;
	var $mac;
	var $ip;
	var $model;
	var $target;
}

class disk {
	var $type;
	var $device;
	var $source;
	var $bus;
	var $driver;
	var $readonly=false;
}


?>
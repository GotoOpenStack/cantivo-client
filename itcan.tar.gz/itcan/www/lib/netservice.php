<?php


class netservice {

	var $id;	// unique id defaults to md5($this->name."-".time())
	var $name;	// defaults to $type_$ip_$port
	var $type;	// type of service: rdp,ica,spice
	var $port;	// port of service
	var $ip;	// ip of service
	var $mc;	// multiple connect: true/false
	
	var $last_seen;		// unix timestamp for when last "seen" by mdns scanner
	var $last_change;	// unix timestamp for when last changed/created
	
	public function __construct($id=false) {
		if($id) $this->load($id);
	}
	
	public function load($id) {
		$configurations = array(
    	'host'     => '127.0.0.1', 
    	'port'     => 6379, 
    	'database' => 1
		);
		$redis = Predis_Client::create($configurations);
		$this->name = $redis->get("ns:".$id.":name");
		if($this->name != "") {
			$this->ip = $redis->get("ns:".$id.":ip");
			$this->port = $redis->get("ns:".$id.":port");
			$this->type = $redis->get("ns:".$id.":type");
			$this->mc = $redis->get("ns:".$id.":mc");
			$this->id = $id;
			return true;
		}
		return false;		
	}
	
	public function del($id) {
		
		$cfg = array(
 		   'host'     => '127.0.0.1', 
		   'port'     => 6379, 
		   'database' => 1
		);
		$redis = Predis_Client::create($cfg);
		if($id != "") {			
			$this->id = $id;
			$redis->del("ns:".$this->id.":name");
			$redis->del("ns:".$this->id.":ip");
			$redis->del("ns:".$this->id.":port");
			$redis->del("ns:".$this->id.":type");
			$redis->del("ns:".$this->id.":mc");
			return true;
		}
		return false;
	}

	public function all() {
	
			$cfg = array(
 			   'host'     => '127.0.0.1', 
			   'port'     => 6379, 
			   'database' => 1
			);
			$redis = Predis_Client::create($cfg);		
			return $redis->keys("ns:*:name");
	}


}

<?php

class nfs_share {


	function __construct($share=false) {
		if(isset($share)) $this->load($share);
	}
	
	function load($key) {
	
		$configurations = array(
    	'host'     => '127.0.0.1', 
    	'port'     => 6379, 
    	'database' => 1
		);
		$redis = Predis_Client::create($configurations);
		
		$ret = array();
		$ret["ip"]	= $redis->get($key.":ip");
		$ret["dir"] = $redis->get($key.":dir");
		$ret["name"] = $redis->get($key.":name");
		$ret["is_mounted"] = $redis->get($key.":is_mounted");
		return $ret;
	}

	function list_shares() {
		$configurations = array(
    	'host'     => '127.0.0.1', 
    	'port'     => 6379, 
    	'database' => 1
		);
		$redis = Predis_Client::create($configurations);

		$all = $redis->keys("nfs:*:name");
		if(count($all)) {

		$ret = array();
		foreach($all as $k) {
			$x = explode(":",$k);
			$ret[] = $x[0].":".$x[1];
		}
		
		return $ret;
		
		}
		return false;
	}

	function del_share($key) {
		$configurations = array(
    	'host'     => '127.0.0.1', 
    	'port'     => 6379, 
    	'database' => 1
		);
		$redis = Predis_Client::create($configurations);
		
		$x = explode(":",$key);
		if(count($x) > 2) $key = $x[0].":".$x[1];
		
		$redis->del($key.":ip");
		$redis->del($key.":dir");
		$redis->del($key.":name");
		$redis->del($key.":is_mounted");
		
	}
	
	function add_share($ip,$dir,$name) {
		$configurations = array(
    	'host'     => '127.0.0.1', 
    	'port'     => 6379, 
    	'database' => 1
		);
		$redis = Predis_Client::create($configurations);

		$key = md5($ip.$dir.$name);
		
		if(!$redis->get("nfs:".$key.":name")) {
		 $redis->set("nfs:".$key.":ip", $ip);
		 $redis->set("nfs:".$key.":dir", $dir);
		 $redis->set("nfs:".$key.":name", $name);
		 $redis->set("nfs:".$key.":is_mounted", "no");
		 return true;
		}
		
		return false;
	}	
	
}
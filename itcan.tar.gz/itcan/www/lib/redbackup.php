<?php

$file = file_get_contents("/tmp/dump.rdb");

print strlen($file);
print "<br>";
print strlen(base64_encode($file));
print "<br>";
print strlen(serialize($file));
print "<br>";
print strlen(gzcompress($file, 9));

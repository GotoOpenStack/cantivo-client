<?php

class redcache {

	var $key;
	var $value;
	var $ttl;
	var $timestamp;
	
	var $redis_conf = array(
    	'host'     => '127.0.0.1', 
    	'port'     => 6379, 
    	'database' => 1
	);
	
	function __construct($key=false) {
		if($key) {
			$this->load($key);
		}
	}
	
	function write($key,$value,$ttl=120) {
		$redis = Predis_Client::create($this->redis_conf);
		$redis->set("cache:".$key.":time", time() + $ttl);
		$redis->set("cache:".$key.":value", $value);
		return true;
	}
	
	function load($key) {
		$redis = Predis_Client::create($this->redis_conf);
		
		$this->timestamp = $redis->get("cache:".$key.":time");
		$this->value = $redis->get("cache:".$key.":value");
		
		/*if(time() < $this->timestamp) {
			$this->invalidate($key);
		}
		*/
		
		return true;
	}
	
	function revalidate($key,$ttl) {
		$redis = Predis_Client::create($this->redis_conf);
		$redis->set("cache:".$key.":time", time() + $ttl);
	}
	
	function invalidate($key) {
		$redis = Predis_Client::create($this->redis_conf);
		$redis->del("cache:".$key.":ttl");
		$redis->del("cache:".$key.":time");
		$redis->del("cache:".$key.":value");
	}
}
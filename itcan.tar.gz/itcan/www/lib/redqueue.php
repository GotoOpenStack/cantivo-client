<?php
include_once("predis.php");
class redqueue {
	
	var $queue;
	var $len;
	var $red_conf = array(
    	'host'     => '127.0.0.1', 
    	'port'     => 6379, 
    	'database' => 1
	);
	
	public function __construct($queue) {
		$this->queue = $queue;
		if($queue != "") $this->len = $this->len();
	}

	public function pop() {
		$redis = Predis_Client::create($this->red_conf);
   		$ret = $redis->rpop($this->queue);
		$this->len = $this->len();
		return $ret;
	}
	
	public function push($data) {
		$redis = Predis_Client::create($this->red_conf);
   		if($redis->lpush($this->queue, $data)) {
   		
   			$this->len = $this->len();
   			return true;
   		
   		}
   		return false;
	}
	
	public function len() {
		if($this->queue) {
			$redis = Predis_Client::create($this->red_conf);
   			return $redis->llen($this->queue);
   		}
   		return false;
	}
	
}



echo "hei<pre>";

$rq = new redqueue("testqueue");

print_r($rq);
/*
$n=1;
while($n<110) {
if($rq->push("banan".$n)) print $n;
$n++;
}
$rq->len = $rq->len();
print_R($rq);
*/
print "<br>";
$n=1;
while($n<6) {
print $rq->pop();
$n++;
}

print_r($rq);

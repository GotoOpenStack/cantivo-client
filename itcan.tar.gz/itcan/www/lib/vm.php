<?php
print "yo".time();
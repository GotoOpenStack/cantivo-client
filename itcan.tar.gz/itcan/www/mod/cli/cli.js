
function handle(path) {
    $(".cmddiv:visible").hide();
    var p = $(path.replace('/','-'));
    if (!p.length) {
        p = $('#notfound');
        p.find('.command').text(path.substring(1));
    }
    p.show();
}

function addtopanel(text) {

text2 = " " + text;

$pane1 = $('#pane1');
var autoScroll = $pane1.data('jScrollPanePosition') == $pane1.data('jScrollPaneMaxScroll');
			$pane1.append(
								$('<p>' + text2 + '</p>')
									
								)
							.jScrollPane(
								{
									scrollbarWidth: 20, 
									scrollbarMargin: 10,
									animateTo: true
								}
							);
							
			if (autoScroll)
			{
				$pane1[0].scrollTo($pane1.data('jScrollPaneMaxScroll'));
			}
						
						
						
						}


$.fn.show = function() {
    return $(this).removeClass('hidden').removeClass('alwaysHidden');
};
$.fn.hide = function() {
    return $(this).addClass('hidden');
};
$.fn.blink = function() {
    var el = $(this);
    el.css('visibility', 'hidden');
    setTimeout(function() {
        el.css('visibility', '');
        setTimeout(function() {
            el.blink();
        }, 500);
    }, 500);
};



$('a.command').live('mouseover', function() {
    $('#cursor').hide();
    $('#command').text($(this).text());
});

$('a.command').live('mouseout', function() {
    $('#cursor').show();
    $('#clicommand').text('');
});

$('a.command').live('click', function() {
    handle($(this).attr('href'));
});


$(function() {
    handle(location.hash);
    $('#cursor').blink();
    $(document).bind('keypress', function(event) {
        if (event.altKey || event.ctrlKey || event.metaKey) return;
        if (event.keyCode == 8) { // Backspace
            $('#clicommand').text($('#clicommand').text().substring(0, $('#clicommand').text().length-1));
            return false;
        } else if (event.keyCode == 13) { // Enter
            //location.hash = $('#clicommand').text();
            
            if($('#clicommand').text() != "") {
            addtopanel("# "+$('#clicommand').text());
            //handle(location.hash);
            //window.location.href = '?m=' +  $('#clicommand').text().replace(' ', '/');
            $('#clicommand').text('');
            }
            
        }
        if (event.charCode) {
            var c = String.fromCharCode(event.charCode);
            $('#clicommand').text($('#clicommand').text() + c);
        }
    });
    $(document).bind('keydown', function(event) {
        if (event.altKey || event.ctrlKey || event.metaKey) return;
        if (event.keyCode == 9) { // Tab
            var t = $('#clicommand').text();
            $('.cmddiv').each(function(i, el) {
                if ($(el).attr('id').substring(0, t.length) == t) {
                    $('#clicommand').text($(el).attr('id'));
                    return false;
                }
            });
        }
    });
});




<?php
print "hehehehhehehe";
		<?php
		$cli = new cli();
		
		print $cli->ex(pwd);
		//print $cli->ex(ls);
	
		?>
		<a href="javascript:;" id="add-content-ajax">here</a>
		<p id="intro" style="display:none;"> 
			# <?php print exec("uname -a"); ?>&nbsp;<br/>
			# <?php print exec("uptime"); ?>&nbsp;<br/>
			# &nbsp;<br/>
			# &nbsp;<br/>
			# &nbsp;<br/>
			# &nbsp;<br/>
			# &nbsp;<br/>
			# &nbsp;<br/>
			# &nbsp;<br/>
			# &nbsp;<br/>
			# &nbsp;<br/>
			# &nbsp;<br/>
			# &nbsp;<br/>
			# &nbsp;<br/>
			# &nbsp;<br/>
		</p> 
		
		
		
		<div class="holder"> 
		<div class="holder orange-bar"> 
			<h3>&gt; CLI</h3>
			<div id="pane1" class="scroll-pane" style="font-size: 0.5em; height: 200px;"> 
				# &nbsp;<br/>
			</div> 
		</div>
		
		
		<br/>
		<script src="mod/cli/cli.js" type='text/javascript'></script> 
		
		 <div class='line center smallAir border dim'> 
         

       <div class='line' id='prompt'> 
          <div class='unit'> 
            &gt;&nbsp;
          </div> 
          <div class='unit command' id='clicommand'></div> 
          <div class='bright unit' id='cursor'> 
            |
          </div> 
        </div> 
      </div> 
      
		<p style="font-size: 0.5em; clear: right;"> 
			<a href="javascript:;" id="add-content">x</a>
		</p> 
		
		
		<script type="text/javascript"> 

			$pane1 = $('#pane1');
			var autoScroll = $pane1.data('jScrollPanePosition') == $pane1.data('jScrollPaneMaxScroll');
			$pane1.append(
								$('<p></p>')
									.html(
										$('#intro').html()
									)
								)
							.jScrollPane(
								{
									scrollbarWidth: 20, 
									scrollbarMargin: 10,
									animateTo: true
								}
							);
							
						if (autoScroll)
						{
							$pane1[0].scrollTo($pane1.data('jScrollPaneMaxScroll'));
						}
						
			$(function()
			{
				// this initialises the demo scollpanes on the page.
				$('#pane1').jScrollPane();
 
				reinitialiseScrollPane = function()
				{
					$('#pane1').jScrollPane();
				}
 
				$('#add-content-ajax').bind(
					'click',
					function()
					{
					
						$('#pane1').load('mod/cli/cliax.php', '');
					    
					    if (autoScroll)
						{
							$pane1[0].scrollTo($pane1.data('jScrollPaneMaxScroll'));
						}

					
						//$('#pane1').load('mod/cli/cliax.php', '', reinitialiseScrollPane);
					}
				);
				// and this allows you to click the link to reduce the amount of content in
				// #pane1 and reinitialise the scrollbars.
				$('#remove-content').bind(
					'click',
					function()
					{
						$('#pane1').empty().append($('<p>Nothing to see here</p>')).jScrollPane({scrollbarWidth:20, scrollbarMargin:10});
					}
				);
			});
			
			
					
						
			$(function()
			{
				$('#add-content').bind(
					'click',
					function()
					{
						$pane1 = $('#pane1');
						var autoScroll = $pane1.data('jScrollPanePosition') == $pane1.data('jScrollPaneMaxScroll');
						$pane1.append(
								$('<p></p>')
									.html(
										$('#intro').html()
									)
								)
							.jScrollPane(
								{
									scrollbarWidth: 20, 
									scrollbarMargin: 10,
									animateTo: true
								}
							);
						if (autoScroll)
						{
							$pane1[0].scrollTo($pane1.data('jScrollPaneMaxScroll'));
						}
						$pane2 = $('#pane2');
						autoScroll = $pane2.data('jScrollPanePosition') == $pane2.data('jScrollPaneMaxScroll');
						$pane2.append(
								$('<p></p>')
									.html(
										$('#intro').html()
									)
								)
							.jScrollPane(
								{
									scrollbarWidth: 20, 
									scrollbarMargin: 10
								}
							);
						if (autoScroll)
						{
							$pane2[0].scrollTo($pane2.data('jScrollPaneMaxScroll'));
						}
					}
				);
			});
			
		</script> 
		
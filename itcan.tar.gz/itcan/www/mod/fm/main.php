<script type='text/javascript'>
var headers = [{"text":"#","key":"id","sortable":false,"fixedWidth":false,"defaultWidth":"60px"},
				{"text":"File","key":"File","defaultWidth":"558px"},
				{"text":"VSize","key":"VSize"},
				{"text":"DSize","key":"DSize"},
				{"text":"Format","key":"Format"}];


var data = [
<?php
$d[] = "/vm/";
$d[] = "/vm/ssd/";
$d[] = "/iso/";
foreach($d as $dir) {
	print retdir($dir);
}

$n=1;
function retdir($path) {
$dir_handle = @opendir($path) or die("Unable to open $path");

$libvirt = new libvirt();
$r = "";
while ($file = readdir($dir_handle)) {
if($file != ".." && $file != "." && $file != "lost+found" && !is_dir($file) && !is_link($file)) { 

if(strpos($file,"qcow2") === false AND strpos($file,"iso") === false AND strpos($file,"img") === false AND strpos($file,"raw") === false AND strpos($file,"qcow") === false) {
	
} else {
$info = $libvirt->qemu_img_info($path.$file);
$r .= '{"id":0,"File":"'.$path.$file.'","VSize":"'.$info['vsize'].'","DSize":"'.$info['dsize'].'","Format":"'.$info['format'].'"},';

$n++;

}


}
}
closedir($dir_handle);
return $r;
}

?>
];


Window.onDomReady( function(){
				
				//mootable = new MooTable( $('test'), {debug: true, height: '200px', headers: headers, data: data, sortable: true, useloading: false, resizable: true } );
				function exampleClick(ev){
				//	debug.log( 'You picked row ' + (this.data.id+1) );
				}
				mootable = new MooTable( 'test', {debug: false, height: '600px', headers: headers, sortable: true, useloading: true, resizable: true});
				mootable.addEvent( 'afterRow', function(data, row){
					//debug.log( row );
					row.cols[0].element.innerHTML = ( data.id + 1);
					row.cols[2].element.setStyle('cursor', 'pointer');
					row.cols[2].element.addEvent( 'click', exampleClick.bind(row) );
				});
				mootable.loadData( data );
				});
</script>
<div id='test'>&nbsp;</div>
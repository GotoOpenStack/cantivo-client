<script type="text/javascript" src="js/jquery-min.js"></script>
<script src="theme2/nosql.js" type='text/javascript'></script> 

<div id='ajuda'> 
          &gt; help
          <div class='gapLeft'> 
            
            <div class='dim'> 
              Available modules:
            </div> 
            
           <?php
/*
unset($mods);
$mods[] = "home";
$mods[] .= "vm";
$mods[] .= "pxe";
$mods[] .= "image";
$mods[] .= "fm";
*/
$n=1;
foreach($mods as $m) {
	
	print "<div class='line'> 
              <a class='command unit size1of4' href='".$m."'>".$m."</a> 
              <div class='lastUnit size3of4'> 
                 bla bla bla
              </div> 
            </div>";
}


?>
            
          </div> 
</div> 

<div class='line gapTop' id='prompt'> 
          <div class='unit'> 
            &gt;&nbsp;
          </div> 
          <div class='unit command' id='command'></div> 
          <div class='bright unit' id='cursor'> 
            |
          </div> 
        </div> 
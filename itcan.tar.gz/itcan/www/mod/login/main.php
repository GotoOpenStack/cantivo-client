
<form method="post">

<ul style="padding-left: 275px;">

<li>Username<br/>
<input type="text" name="username">
</li>

<li>Password<br/>
<input type="password" name="password">
</li>

<li><br/>
<span style="padding-left: 175px;">
<input type="submit" value="login">
</span>
</li>

</ul>


</form>

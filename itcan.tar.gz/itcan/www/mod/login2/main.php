<style>
account_form.css (line 1)
body {
min-width:900px;
padding-left:0;
padding-right:0;
}
fullscreen.css (line 1)
body {
background:url("/images/background.png?4") repeat-x scroll center top #2C4762;
color:#444444;
font:14px/1.4 Arial,Helvetica,sans-serif;
margin:0;
padding:0;
}
global.css (line 3)
*, :active, :focus {
outline:0 none;
}

#content {
    background: transparent;
}

  #content #inset {
      height: 40px;
      width: auto;
  }
  
    #content #inset #inset_shimmer {
        height: 247px;
        width: auto;
        background: url('images/inset_shimmer.jpg') top center no-repeat transparent;
    }
    
      #content #inset #inset_shimmer .slogan {
          margin: 50px auto 0 auto;
          color: #e6ecf2;
          font-family: Arial, Helvetica, Verdana, sans-serif;
          font-size: 60px;
          text-align: center;
      }
      
      #content #inset #inset_shimmer .slogan#easiest {
          width: 786px;
          height: 79px;
          background: url('images/slogan_easiest.png?alpha') top left no-repeat transparent;
          text-indent: -9999px;
      }
      
      #content #inset #inset_shimmer .slogan#answer {
          width: 969px;
          height: 58px;
          background: url('images/slogan_answer.png?alpha') top left no-repeat transparent;
          text-indent: -9999px;
      }
      
      #content #inset #inset_shimmer .slogan#welcomeback {
          width: 486px;
          height: 65px;
          background: url('images/slogan_welcomeback.png?alpha') top left no-repeat transparent;
          text-indent: -9999px;
      }
      
      #content #inset #inset_shimmer .slogan#postcustomize {
          width: 1052px;
          height: 70px;
          background: url('images/slogan_postcustomize.png?alpha') top left no-repeat transparent;
          text-indent: -9999px;
      }
      
#content #form {
    position: relative;
    top: -90px;
    width: 615px;
    margin: 0 auto;
    padding-bottom: 30px;
    background: url('images/form_shadow_full.png') bottom center no-repeat transparent;
}

    #content #form #form_inner {
        background: url('images/form_shimmer.png') top center no-repeat #e1f0fa;
        border: 1px solid #fff;
        width: 498px; /*  558 - 30 - 30 = 498  */
        margin: 0 auto;
        padding: 30px;
    }
    
        #content #form #form_note {
            width: 490px;
            margin: 0 auto;
            padding: 10px 20px;
            background: url('images/form_note_bg.png') top left repeat-x #7db261;
            border-top: 1px solid #a5e78b;
            border-left: 1px solid #a5e78b;
            border-right: 1px solid #a5e78b;
            font-family: Arial, Helvetica, Verdana, sans-serif;
            font-size: 16px;
            color: #3d721d;
            border-top-left-radius:10px;
            border-top-right-radius:10px;
            -webkit-border-top-left-radius:10px;
            -webkit-border-top-right-radius:10px;
            -moz-border-radius-topleft:10px;
            -moz-border-radius-topright:10px;
        }
        
            #content #form #form_note a {
                text-decoration: none;
                color: #3d721d;
            }
            
                #content #form #form_note a:hover {
                    color: #255607;
                }
        
            #content #form #form_note b {
                color: #356617;
            }
    
        #content #form #form_inner #account_form {
            margin: 0;
            padding: 0;
        }
        
            #content #form #form_inner #account_form label {
                font-family: Arial, Helvetica, Verdana, sans-serif;
                font-size: 18px;
                color: #657788;
                display: block;
                margin-bottom: 5px;
            }
        
                #content #form #form_inner #account_form label .disclaimer {
                    color: #9cacbc;
                    font-family: "Lucida Grande", Verdana, sans-serif;
                    font-size: 11px;
                }
        
            #content  #form #form_inner #account_form .text_field {
                width: 480px;
                font-family: Georgia, Times, "Times New Roman", serif;
                font-size: 28px;
                border: 1px solid #97b5d2;
                background: url('images/input_bg.png') top left repeat-x #f7fcff;
                color: #25313c;
            }
        
            #content  #form #form_inner #account_form .text_field:focus {
                background-color: #f9f8e4;
            }

ul.errors {
    margin: 0 0 25px 0;
    padding: 15px 15px 5px 15px;
    background: url('images/form_error_bg.png') bottom left repeat-x #ef858d;
    font-family: Arial, Helvetica, Verdana, sans-serif;
    font-size: 18px;
    font-weight: normal;
    color: #631110;
    border-top: 1px solid #7d454a;
    border-left: 1px solid #ce7076;
    border-right: 1px solid #ce7076;
    border-radius: 10px;
    -moz-border-radius: 10px;
    -webkit-border-radius: 10px;
}

    ul.errors li {
        margin: 0 0 10px 0;
    }

#content .blue_note {
    position: relative;
    top: -50px;
}




</style>


 
                
<div id="content">
<!--[if IE 6]>
    <style type="text/css">
        #content  #form #form_inner #account_form .text_field, 
        #content #form #form_inner,
        #content #form {
            background-image: none;
        }
        
        #footer {
            margin-top: -100px
        }
    </style>
<![endif]-->


<div id="inset">
    <div id="inset_shimmer">
        <div class="slogan" id="welcomeback">Welcome back!</div>
    </div>
</div>

<div id="form">
    <div id="form_inner">
        <form action="/login" method="post" id="account_form">
            
            
            <label for="email">Email address</label>
            <div style="border: 1px solid rgb(255, 255, 255); margin-bottom: 20px;"><input name="email" id="email" class="text_field" value="" type="text"></div>

            <label for="password">Password</label>
            <div style="border: 1px solid rgb(255, 255, 255); margin-bottom: 30px;"><input name="password" class="text_field" type="password"></div>

            <div>
                <a href="/forgot_password" style="color: rgb(146, 159, 171); float: right; font-size: 14px; padding-top: 13px;">Forgot your password?</a>
                
                <input value="Log in" class="big_button" type="submit">
            </div>

                    </form>
    </div>
</div>     


</div>
       
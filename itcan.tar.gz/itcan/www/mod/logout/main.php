<?php
$world->goto("?");


<table style="font-size: 0.8em;" width="100%">
<?php

$nfs = new nfs_share();

if($_GET["del"] == 1 && isset($_GET["share"])) {
	$share = base64_decode($_GET["share"]);
	if($share != "") {
		$nfs->del_share($share);
		print "deleted share: ".$share." -- OK";
		
	}
}

if($_GET["name"] && $_GET["ip"] && $_GET["dir"]) {
	$nfs->add_share($_GET["ip"],$_GET["dir"],$_GET["name"]);
	print "adding share: ".$_GET["ip"].":/".$_GET["dir"]." / ".$_GET["name"]." -- OK";
}
foreach($nfs->list_shares() as $share) {
	
	
	
	$s = $nfs->load($share);
	
	$link = "<a href='?m=nfs&del=1&share=".base64_encode($share)."'>X</a>";
	
	
	print "<tr>";
	print "<td>".$s["name"]."</td>";
	print "<td>".$s["ip"].":/".$s["dir"]."</td>";

	if($s["is_mounted"] == "no") {

	exec("df -h /nfs/".$s["ip"]."/".$s["name"]."",$out);
	$x = explode("  ",$out[1]);	
	$df = "Total: ".$x[4]." Used:".$x[5]." Free:".$x[6];
	print "<td>".$df."</td>";

	} else {
	
	print "<td>NOT-MOUNTED!</td>";	
	}
	
	print "<td>".$link."</td></tr>";

unset($df);
unset($out);
unset($x);

}

?>

</table>

<br/>
<hr><div style="font-size: 0.6em;">
<form value="GET">
<input type="hidden" name="m" value="nfs">
NAME <input type="text" name="name">
REMOTE IP <input type="text" name="ip">
REMOTE DIR <input type="text" name="dir">
<input type="submit" value="ok">
</form>
</div>

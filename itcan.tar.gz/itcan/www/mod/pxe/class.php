<?php

class inventory {

	var $mac;
	var $tag;
	
	var $type;
	var $server_type;
	
	var $types = array("desktop","server","router","switch");
	var $server_types = array("lin_ts","win_ts", "win_desktop","kvm");


}


function getword() {

if (!$excuses = @file("mod/pxe/wordlist.txt"))
        return "couldn't read excuse file '$excusefile'";

mt_srand((double)microtime()*1000000);
return trim($excuses[mt_rand(0, count($excuses)-1)]);

}


/*

//$exec = exec("arp -a -n", $e);
$exec = exec("arp -a -n|grep -v '52:54:'", $e);
$cfg = new pxecfg();

foreach($e as $mac) {
	
	if(strstr($mac,":")) {
		$x = explode(" at ",$mac);
		$xx = explode(" [ether]",$x[1]);		
		$xxx = explode("(",$mac);
		$xxxx = explode(")",$xxx[1]);
		
		$ip = trim($xxxx[0]);
		$mac = strtolower(trim($xx[0]));
		
		$cfg->mac = $mac;
		$cfg->macmd5 = md5($mac);

		if($cfg->loadmac()) { $conf = "<a style='color: blue;' href='?m=pxecfg&i=".$cfg->macmd5."'>EDIT</a>"; } 
		else { $conf = "<a style='color: red;' href='?m=pxecfg&i=".$cfg->macmd5."'>CONFIGURE</a>"; }
		print "IP: ".$ip." MAC: ".$mac." -- ".$conf." <br/>";
		
	}
}
#MENU_ITEM_01="Desktop"
#MENU_COMMAND_01="ldm"
#MENU_ITEM_02="Windows 7 (RDP)"
#MENU_COMMAND_02="rdesktop 10.10.0.199"
#MENU_ITEM_03="Windows 7 (SPICE)"
#MENU_COMMAND_03="spice"
#MENU_TITLE="SELECT PROFILE: "

# Example of a serial printer attached to /dev/ttyS1 on workstation ws001
#
#[ws001]
#    PRINTER_0_DEVICE   = /dev/ttyS1
#    PRINTER_0_TYPE     = S		# P-Parallel, S-Serial
#    PRINTER_0_PORT     = 9100		# tcp/ip port: defaults to 9100
#    PRINTER_0_SPEED    = 9600		# baud rate: defaults to 9600
#    PRINTER_0_FLOWCTRL = S		# Flow control: S-Software (XON/XOFF),
#					# H-Hardware (CTS/RTS)
#    PRINTER_0_PARITY   = N		# Parity: N-None, E-Even, O-Odd
#					# (defaults to 'N')
#    PRINTER_0_DATABITS = 8		# Databits: 5,6,7,8 (defaults to 8)



*/

class pxecfgdefault {

	var $SCREEN_01 = "console";
	var $SERVER;
	var $SHUTDOWN_TIME; //064500
	var $X_COLOR_DEPTH="24";
	var $LOCALDEV="True";
	var $SOUND="True";
	var $NBD_SWAP="False";
	var $SYSLOG_HOST;
	var $TIMESERVER;
	var $XKBLAYOUT="no";
	var $LDM_DEBUG="True";
	var $LDM_DIRECTX="True";
	var $VOLUME="70";
	var $PCM_VOLUME="70";
	var $MIC_VOLUME="70";
	var $CD_VOLUME="70";
	var $FRONT_VOLUME="70";
	var $LOCAL_APPS="True";
	
	
	public function writecfg() {
	
		$ret = "[Default]\n";
		if(isset($this->SERVER)) $ret .= "SERVER=".$this->SERVER."\n";		
		
		if(isset($this->SHUTDOWN_TIME)) $ret .= "SHUTDOWN_TIME=".$this->SHUTDOWN_TIME."\n";
		if(isset($this->X_COLOR_DEPTH)) $ret .= "X_COLOR_DEPTH=".$this->X_COLOR_DEPTH."\n";
		if(isset($this->LOCALDEV)) $ret .= "LOCALDEV=".$this->LOCALDEV."\n";
		if(isset($this->SOUND)) $ret .= "SOUND=".$this->SOUND."\n";
		if(isset($this->NBD_SWAP)) $ret .= "NBD_SWAP=".$this->NBD_SWAP."\n";
		if(isset($this->SYSLOG_HOST)) $ret .= "SYSLOG_HOST=".$this->SYSLOG_HOST."\n";
		if(isset($this->TIMESERVER)) $ret .= "TIMESERVER=".$this->TIMESERVER."\n";
		if(isset($this->XKBLAYOUT)) $ret .= "XKBLAYOUT=".$this->XKBLAYOUT."\n";
		if(isset($this->LDM_DEBUG)) $ret .= "LDM_DEBUG=".$this->LDM_DEBUG."\n";
		if(isset($this->LDM_DIRECTX)) $ret .= "LDM_DIRECTX=".$this->LDM_DIRECTX."\n";
		if(isset($this->LOCAL_APPS)) $ret .= "LOCAL_APPS=".$this->LOCAL_APPS."\n";
		
		if(isset($this->VOLUME)) $ret .= "VOLUME=".$this->VOLUME."\n";
		if(isset($this->PCM_VOLUME)) $ret .= "PCM_VOLUME=".$this->PCM_VOLUME."\n";
		if(isset($this->MIC_VOLUME)) $ret .= "MIC_VOLUME=".$this->MIC_VOLUME."\n";
		if(isset($this->CD_VOLUME)) $ret .= "CD_VOLUME=".$this->CD_VOLUME."\n";
		if(isset($this->FRONT_VOLUME)) $ret .= "FRONT_VOLUME=".$this->FRONT_VOLUME."\n";
		
		if(isset($this->SCREEN_01)) $ret .= "SCREEN_01=".$this->SCREEN_01."\n";
		
	
		return $ret;	
	}
	
}

class pxecfg {

	var $mac;
	var $tag;
	
	var $screen_1 = "";
	var $screen_2 = "";
	var $screen_3 = "";
	var $screen_4 = "";
	var $screen_5 = "";
	var $screen_6 = "";
	var $screen_7 = "";
		
	var $ldm_autologin;
	var $ldm_username;
	var $ldm_password;
	
	var $rdp_server;
	var $rdp_port;
	
	var $spice_server;
	var $spice_port;

	public function __construct($mac=false) {
		if($mac != "") {
			$this->mac = $mac;
			$this->macmd5 = md5($this->mac);
			
			$this->loadmac();
		}
	}	
	
	public function allkeys() {
		
			$cfg = array(
 			   'host'     => '127.0.0.1', 
			   'port'     => 6379, 
			   'database' => 5
			);
			$redis = Predis_Client::create($cfg);
			
			return $redis->keys("pxecfg:*:mac");
	}
	
	public function loadkey($hash) {
			$cfg = array(
 			   'host'     => '127.0.0.1', 
			   'port'     => 6379, 
			   'database' => 5
			);
			$redis = Predis_Client::create($cfg);
			
			$mac = $redis->get($hash);
			if($mac != "") {
				$this->mac = $mac;
				$this->tag = $redis->get("pxecfg:".md5($mac).":tag");
				$this->screen_5 = $redis->get("pxecfg:".md5($mac).":screen_5");
				$this->ldm_autologin = $redis->get("pxecfg:".md5($mac).":ldm_autologin");
				
				$this->ldm_username = $redis->get("pxecfg:".md5($mac).":ldm_username");
				$this->ldm_password = $redis->get("pxecfg:".md5($mac).":ldm_password");
				$this->rdp_server = $redis->get("pxecfg:".md5($mac).":rdp_server");
				$this->rdp_port = $redis->get("pxecfg:".md5($mac).":rdp_port");
				$this->spice_server = $redis->get("pxecfg:".md5($mac).":spice_server");
				$this->spice_port = $redis->get("pxecfg:".md5($mac).":spice_port");
				return true;
			}
			return false;
	}
	
	public function gencfg() {
		$ret = "\n#".$this->tag."\n[".$this->mac."]\n";
		if($this->screen_5 != "") { 
			
			switch($this->screen_5) {
				case 'rdp':
					$this->screen_5 = "rdesktop -k no -N -r sound:local -a 32 ".$this->rdp_server;
				
				default:
					$this->screen_5 = $this->screen_5;
			}
			
			
			if($this->screen_5 != "") $ret .= 'SCREEN_05="'.$this->screen_5.'"'."\n";
			
			if($this->spice_server != "") $ret .= 'SPICE_SERVER='.$this->spice_server.''."\n";
			if($this->spice_port != "") $ret .= 'SPICE_PORT='.$this->spice_port.''."\n";
			
			if($this->ldm_username != "") $ret .= 'LDM_USERNAME='.$this->ldm_username.''."\n";
			if($this->ldm_password != "") $ret .= 'LDM_PASSWORD='.$this->ldm_password.''."\n";
			
			if($this->ldm_username != "" && $this->ldm_password != "") $this->ldm_autologin="True";
			if($this->ldm_autologin != "") $ret .= 'LDM_AUTOLOGIN='.$this->ldm_autologin.''."\n";
			
		}
		print $ret;
	}
	
	public function clearcfg() {
		
			if($this->mac && !$this->macmd5) $this->macmd5 = md5($this->mac);
			if(!$this->mac) return false;
			
			$cfg = array(
 			   'host'     => '127.0.0.1', 
			   'port'     => 6379, 
			   'database' => 5
			);
			$redis = Predis_Client::create($cfg);

			
			$redis->del("pxecfg:".$this->macmd5.":configured");
			$redis->del("pxecfg:".$this->macmd5.":tag");
			$redis->del("pxecfg:".$this->macmd5.":mac");
			$redis->del("pxecfg:".$this->macmd5.":ldm_username");
			$redis->del("pxecfg:".$this->macmd5.":ldm_password");
			$redis->del("pxecfg:".$this->macmd5.":ldm_autologin");
			$redis->del("pxecfg:".$this->macmd5.":spice_server");
			$redis->del("pxecfg:".$this->macmd5.":spice_port");
			$redis->del("pxecfg:".$this->macmd5.":screen_5");
			
			
			return true;
	}
	
	public function writecfg() {
			
			$cfg = array(
 			   'host'     => '127.0.0.1', 
			   'port'     => 6379, 
			   'database' => 5
			);
			$redis = Predis_Client::create($cfg);
			
			if($this->tag != "") $redis->set("pxecfg:".$this->macmd5.":tag", $this->tag);
			if($this->mac != "") $redis->set("pxecfg:".$this->macmd5.":mac", $this->mac);
			
			if($this->ldm_username != "") $redis->set("pxecfg:".$this->macmd5.":ldm_username", $this->ldm_username);
			if($this->ldm_password != "") $redis->set("pxecfg:".$this->macmd5.":ldm_password", $this->ldm_password);
			if($this->ldm_username != "" && $this->ldm_password != "") $this->ldm_autologin="True";
			if($this->ldm_autologin != "") $redis->set("pxecfg:".$this->macmd5.":ldm_autologin", $this->ldm_autologin);
			
			if($this->spice_server != "") $redis->set("pxecfg:".$this->macmd5.":spice_server", $this->spice_server);
			if($this->spice_port != "") $redis->set("pxecfg:".$this->macmd5.":spice_port", $this->spice_port);
					
			if($this->screen_5 != "") $redis->set("pxecfg:".$this->macmd5.":screen_5", $this->screen_5);
						
			$redis->set("pxecfg:".$this->macmd5.":configured", "1");
			return true;
	}
	
	
	public function loadmac() {
		if($this->mac != "") {
		
			$cfg = array(
 			   'host'     => '127.0.0.1', 
			   'port'     => 6379, 
			   'database' => 5
			);
			$redis = Predis_Client::create($cfg);
			
			if($redis->get("pxecfg:".$this->macmd5.":configured")) {
				
				$this->tag = $redis->get("pxecfg:".$this->macmd5.":tag");
				$this->screen_1 = $redis->get("pxecfg:".$this->macmd5.":screen_1");
				$this->screen_2 = $redis->get("pxecfg:".$this->macmd5.":screen_2");
				$this->screen_3 = $redis->get("pxecfg:".$this->macmd5.":screen_3");
				$this->screen_4 = $redis->get("pxecfg:".$this->macmd5.":screen_4");
				$this->screen_5 = $redis->get("pxecfg:".$this->macmd5.":screen_5");
				$this->screen_6 = $redis->get("pxecfg:".$this->macmd5.":screen_6");
				$this->screen_7 = $redis->get("pxecfg:".$this->macmd5.":screen_7");
				
				return true;
			}
			
			return false;

		}
	}
}



class allmac {
	var $ex_vms = false; //exclude any local kvm vm's
	
	public function __construct($ex_vms=0) {
		if($ex_vms > 0)
		 $this->ex_vms = $ex_vms;
		$this->doit();
	}
	
	private function doit() {
	
	if($this->ex_vms == 1) { 
	$exec = exec("arp -a -n|grep -v 'at 52:54:'", $e); 
	} elseif($this->ex_vms == 2) {
	$exec = exec("arp -a -n|grep 'at 52:54:'", $e); 
	} else {
	$exec = exec("arp -a -n", $e);
	}
	
	$ret = array();
	
	foreach($e as $mac) {
		if(strstr($mac,":")) {
			$x = explode(" at ",$mac);
			$xx = explode(" [ether]",$x[1]);		
			$xxx = explode("(",$mac);
			$xxxx = explode(")",$xxx[1]);
		
			$ip = trim($xxxx[0]);
			$mac = strtolower(trim($xx[0]));
		
			$ret[$mac] = $ip;
		}
	}
		$this->macs = $ret;
	}
}
<?php
error_reporting(E_ALL); 
ini_set("display_errors", 1); 


include("class.php");


if(isset($_GET["delete"]) && $_GET["mac"] != "") {
	$cfg = new pxecfg(base64_decode($_GET["mac"]));
	$cfg->clearcfg();
}

if(!isset($_GET["cfg"])) {

$bvm = new bootvm();
$all = $bvm->getall();
$n=1;
print "<h2>bootvm</h2><table width='100%' style='margin: 10px;'>";
foreach($all as $vm) {
	$bvm->load($vm);
	print "<tr><td>".$n."</td><td>".$bvm->ip."</td><td>".$bvm->user."</td><td>yes</td><td>yes</td></tr>";	
	$n++;
}
print "</table><br/>";

$a = new allmac(2);

//print "<h1>PXE boot configuration</h1>";

print "<h2>virtual machines</h2><table width='100%' style='margin: 10px;'>";
print "<tr style='color: #fff;'><td>tag</td><td>mac</td><td>current ip</td><td>&nbsp;</td></tr>";
foreach($a->macs as $m => $i) {
$cfg = new pxecfg();
$cfg->mac = $m;
$cfg->macmd5 = md5($m);



if($cfg->loadmac()) { 

if(!$bvm->getkeybyip($i)) { 
	$conf = "<a style='color: red;' href='pxe&delete=1&mac=".base64_encode($cfg->mac)."'>DELETE</a>"; 
} else {
	$conf = "<font color='#ffcc00'>BOOTVM</font>";
}

} else { 

if(!$bvm->getkeybyip($i)) { 
 $conf ="<a style='color: green;' href='pxe&cfg=".base64_encode($cfg->mac)."'>CONFIGURE</a>"; 
} else {
	$conf = "<font color='#ffcc00'>BOOTVM</font>";
}




}

if($cfg->tag == "") $cfg->tag = "-";
 print "<tr><td>".$cfg->tag."</td><td>".$m."</td><td>".$i."</td><td>".$conf."</td></tr>";
}
print "</table>";


$a = new allmac(1);
print "<br/><h2>physical machines</h2><table width='100%' style='margin: 10px;'>";
print "<tr style='color: #fff;'><td>tag</td><td>mac</td><td>current ip</td><td>&nbsp;</td></tr>";
foreach($a->macs as $m => $i) {
$cfg = new pxecfg();
$cfg->mac = $m;
$cfg->macmd5 = md5($m);
if($cfg->loadmac()) { 
 $conf = "<a style='color: red;' href='pxe&delete=1&mac=".base64_encode($cfg->mac)."'>DELETE</a>"; 
} else { 
 $conf ="<a style='color: green;' href='pxe&cfg=".base64_encode($cfg->mac)."'>CONFIGURE</a>"; 
}

if($cfg->tag == "") $cfg->tag = "-";
 print "<tr><td>".$cfg->tag."</td><td>".$m."</td><td>".$i."</td><td>".$conf."</td></tr>";
}
print "</table>";







//print "<pre>";
print "<br/><br/><br/><hr><pre>";


$cfg = new pxecfg();
$pxecfgdefault = new pxecfgdefault();
print $pxecfgdefault->writecfg();

$allkeys = $cfg->allkeys();
foreach($allkeys as $k) {
	if($cfg->loadkey($k)) {
		print $cfg->gencfg();
	}
	
}
print "</pre>";




} else {

$mac = base64_decode($_GET["cfg"]);

$cfg = new pxecfg($mac);
//$xuuid = exec("/usr/bin/uuidgen",$uuid);

//$uuid[0] = strtoupper(substr(md5($mac), 25, strlen(md5($mac))));

$uuid[0] = strtoupper(substr(getword(), 0, 2))."".rand(10,99);

if(isset($_POST["tag"])) {
if($_POST["tag"] == "") $_POST["tag"] = $uuid[0];
foreach($_POST as $k => $v) {
	$cfg->$k = $v;
}
 //print $cfg->gencfg();
 if($cfg->writecfg()) {
 print "SAVED OK!";
 }
 header("Location: pxe");
}

print "<form method='POST' action='pxe&cfg=".$_GET["cfg"]."'>";

print "<h2>Configuring: ".$mac."</h2>";

print "<span>TAG <input id='tag' type='text' size='8' value='' name='tag'><input type='button' value='gen' onclick='gentag();'></span>";

print "<script type='text/javascript'>";
print "

function gentag() {
	document.getElementById('tag').value = '".$uuid[0]."';
}

function showhide(id){
if (document.getElementById){
obj = document.getElementById(id);
if (obj.style.display == 'none'){
obj.style.display = '';
} else {
obj.style.display = 'none';
}
}
} 

		function s5_sel_ch() {
			sel = document.getElementById('screen_5').options[document.getElementById('screen_5').selectedIndex].value;
			
			switch(sel) {
				
				case 'ldm':
					document.getElementById('s5_spiceoptions').style.display = 'none';
					document.getElementById('s5_rdpoptions').style.display = 'none';
					document.getElementById('s5_autologin').style.display = '';
					break;
				
				case 'rdp':
					document.getElementById('s5_spiceoptions').style.display = 'none';
					document.getElementById('s5_rdpoptions').style.display = '';
					document.getElementById('s5_autologin').style.display = 'none';
					break;
				
				case 'spice':
					document.getElementById('s5_spiceoptions').style.display = '';
					document.getElementById('s5_rdpoptions').style.display = 'none';
					document.getElementById('s5_autologin').style.display = 'none';
					break;
						
				case 'console':
					document.getElementById('s5_spiceoptions').style.display = 'none';
					document.getElementById('s5_rdpoptions').style.display = 'none';
					document.getElementById('s5_autologin').style.display = 'none';
					break;
					
				case 'shell':
					document.getElementById('s5_spiceoptions').style.display = 'none';
					document.getElementById('s5_rdpoptions').style.display = 'none';
					document.getElementById('s5_autologin').style.display = 'none';
					break;
			}
			
			
		}

		function s5_autol_ch() {
		if(document.getElementById('s5_autologin_ch').checked == true) { 
		document.getElementById('s5_autol_dyn').style.display = '';
		} else {
		document.getElementById('s5_autol_dyn').style.display = 'none'; 
		}
			
		}</script>";

print "<br/><br/><span>DESKTOP ";
print "<select onchange='s5_sel_ch()' id='screen_5' name='screen_5'>";
print "<option value='ldm'>LDM</option>";
print "<option value='rdp'>RDP</option>";
print "<option value='spice'>SPICE</option>";
print "<option value='console'>CONSOLE</option>";
print "<option value='shell'>SHELL</option>";
print "</select><br/>";

$rdpoptions = "<div style='display:none;' id='s5_rdpoptions'>IP: <input type='text' name='rdp_server'><br/>PORT: <input type='text' name='rdp_port' value='3389'> </div>";
$spiceoptions = "<div style='display:none;' id='s5_spiceoptions'>IP: <input type='text' name='spice_server'><br/>PORT: <input type='text' name='spice_port'> </div>";


$alogin = "<div id='s5_autologin'><input id='s5_autologin_ch' type='checkbox' onchange='s5_autol_ch();'> autologin <div id='s5_autol_dyn' style='display: none;' >Login:<input type='text' name='ldm_username'><br/>Password:<input type='text' name='ldm_password'></div></div>".$rdpoptions.$spiceoptions."";
print $alogin;
print "<input type='submit' value='save'></form>";



}




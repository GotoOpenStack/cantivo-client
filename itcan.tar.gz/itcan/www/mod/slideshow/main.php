	<div id="main">		
		<div id="hp-img"> 
			<div class="slideshow"> 
				<img src="theme/images/homepage.jpeg" width="600" height="450" alt="" /> 
				<img src="theme/images/homepage2.jpeg" width="600" height="450" alt="" /> 
			</div>	
		</div>	
	</div> 
	<aside> 
	  <p>bla bla</p> 
	  
	  <section id="resume-dl"> 
  <p>Download my resume:</p> 
  <ul> 
	<li><a href="/resume/files/Ed.Wheeler.resume.web.doc">Word Doc</a></li> 
	<li><a href="/resume/files/Ed.Wheeler.resume.web.pdf" target="_blank">PDF</a></li> 
	<li><a href="/resume/files/Ed.Wheeler.resume.web.txt" target="_blank">Plain text</a></li>	
  </ul> 
</section>	  
	  <h4>Recent Projects</h4> 
	  <ul> 
		<li><a href="http://xpresswheelrepair.com/" target="_blank">Xpress Wheel Repair</a><br /> 
			Complete site, including design and valid XHTML/CSS, powered by Drupal.		
		</li>	  
	  </ul> 
	  
	</aside> 

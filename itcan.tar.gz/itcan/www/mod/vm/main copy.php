<?php
$time_s = microtime();
error_reporting(E_ALL); 
ini_set("display_errors", 1); 
 
// REDIS
include("lib/predis.php");

$configurations = array(
    'host'     => '127.0.0.1', 
    'port'     => 6379, 
    'database' => 15
);

$redis = Predis_Client::create($configurations);
/*
$redis->set('VM:001', 'LTS1');
$retval = $redis->get('VM:001');

print_r($retval);
*/

?>

<?php
/// LIBVIRT 
$uri="qemu:///system";
$credentials=Array(VIR_CRED_AUTHNAME=>"root",VIR_CRED_PASSPHRASE=>"n1ntend0");
$conn=libvirt_connect($uri,false,$credentials);
if ($conn==false)
{
    echo ("Libvirt last error: ".libvirt_get_last_error()."\n");
    print_r($credentials);
    exit;
}
else
{
    $hostname=libvirt_get_hostname($conn);
    
    
    $info = libvirt_node_get_info($conn);
    
	echo ("Conneced to libvirt (URI:$uri)\n");
    print "<br>";
    print "ARCH: ".$info['model'];
    print "&nbsp;||&nbsp;";
    print "CPUs: ".($info['cpus']/2);
    print "&nbsp;||&nbsp;";
    print "Sockets: ".($info['sockets']/2);
    print "&nbsp;||&nbsp;";
    print "Cores: ".($info['cores']*2);
    print "&nbsp;||&nbsp;";
    print "Clock: ".(($info['mhz']*($info['cpus']/2)))." Mhz";
    
    print "&nbsp;||&nbsp;";
    print "RAM: ".number_format($info['memory']/1024/1024, 1)." GB";

    print "<br>";
    echo ("Domain count: Active ".libvirt_get_active_domain_count($conn).",Inactive ".libvirt_get_inactive_domain_count($conn).", Total ".libvirt_get_domain_count($conn)."\n");
    
    //print_R($info);
    echo "\n\n";
    
    print "<vmlist><ul>";
    
    $domains=libvirt_list_domains($conn);
    foreach ($domains as $dom)
    {
       
    	
    	$dominfo=libvirt_domain_get_info($dom);
        
        $mem = number_format($dominfo['memory'] / 1024 / 1024, 1);
        $cpu = $dominfo['nrVirtCpu'];
        $state = $dominfo['state'];
        
        switch($state) {
        	case '6':
        		$state = "CRASHED";
        		break;

        	case '5':
        		$state = "SHUTOFF";
         		$img = "shutdown.png";
         	    break;

        	case '4':
        		$state = "SHUTDOWN";
        		$img = "shutdown.png";
        		break;

        	case '3':
        		$state = "PAUSED";
        		break;

        	case '2':
        		$state = "BLOCKED";
        		break;

        	case '1':
        		$state = "RUNNING";
        		$img = "running.png";
        		break;
        		
        	case '0':
        		$state = "VIR_DOMAIN_NOSTATE";
        		break;
        		       		
        	default:
        		$state = "UNKNOWN (".$state.")";
        		$img = "bug.png";
        		
        }
        
        $vm_name = libvirt_domain_get_name($dom);
        $vm_uuid = libvirt_domain_get_uuid_string($dom);
        
		$redis->set($vm_uuid."-NAME", $vm_name);
		$redis->set($vm_uuid."-MEM", $mem);
		$redis->set($vm_uuid."-CPU", $cpu);
		$redis->set($vm_uuid."-STATE", $dominfo['state']);
		$redis->setnx($vm_uuid."-XML", libvirt_domain_get_xml_desc($dom));
		
		
		
		
		$red_name = $redis->get($vm_uuid."-NAME");
		$red_mem = $redis->get($vm_uuid."-MEM");
		$red_cpu = $redis->get($vm_uuid."-CPU");
		$red_cpu_usage = $redis->get($vm_uuid."-CPUTIME");
		$red_xml = $redis->get($vm_uuid."-XML");
		

        
        print "<li><h1><img height='20px' src='theme/images/".$img."'>&nbsp;&nbsp;";
        print "".$red_name."</h1>";
    	print "CPU: ".$red_cpu." (".number_format($red_cpu_usage, 2)."%)<br/>";
        print "RAM: ".$red_mem." GB<br/>";
        //print "<textarea cols='100' rows='20'>".$red_xml."</textarea>";
        
        print "</li>";
        print_r($dominfo);
    	unset($img);
    	unset($red_cpu_usage);
    	
    
    }
}


$time_c = microtime();

print $time_c - $time_s;
?>
</ul></vmlist>


<table>
<tr>
<td>#</td>
<td>xxx</td>
</tr>


</table>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>


<?php


if(isset($_POST["action"]) && isset($_POST["UUID"])) {
	$libvirt = new libvirt($_POST["UUID"]);
			
	switch($_POST["action"]) {
		
		case 'pause':
		$libvirt->suspend();
		print "PAUSED VM: ".$libvirt->uuid;
		break;
		
		case 'resume':
		$libvirt->resume();
		print "RESUMED VM: ".$libvirt->uuid;
		break;

		case 'reboot':
		$libvirt->reboot();
		print "REBOOTED VM: ".$libvirt->uuid;
		break;
		
		case 'stop':
		$libvirt->shutdown();
		print "SHUTDOWN VM: ".$libvirt->uuid;
		break;
		
		case 'destroy':
		$libvirt->destroy();
		print "FORCED SHUTDOWN VM: ".$libvirt->uuid;
		break;
		
		case 'start':
		$libvirt->start();
		print "STARTED VM: ".$libvirt->uuid;
		break;
	
	}
}
?>
<h1>Virtual Machine Configuration</h1>

<div id='vmdiv'>
</div>

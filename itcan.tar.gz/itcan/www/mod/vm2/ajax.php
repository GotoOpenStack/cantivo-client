<?php
if(substr_count($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip')) {
 ob_start("ob_gzhandler");
} else {
 ob_start();
}


$time_s = microtime();
error_reporting(E_ALL); 
ini_set("display_errors", 1); 

// LIBVIRT
include("../../lib/libvirt.php");
$libvirt = new libvirt();

// REDIS
include("../../lib/predis.php");

$configurations = array(
    'host'     => '127.0.0.1', 
    'port'     => 6379, 
    'database' => 1
);

$redis = Predis_Client::create($configurations);
   


$configurations_x = array(
    'host'     => '127.0.0.1', 
    'port'     => 6379, 
    'database' => 2
);

$redis_x = Predis_Client::create($configurations_x);

$configurations_net = array(
    'host'     => '127.0.0.1', 
    'port'     => 6379, 
    'database' => 4
);

$redis_net = Predis_Client::create($configurations_net);

$domains = $redis->keys("vm:*");
  
    print "<vmlist><ul>";
    
    foreach ($domains as $dom)
    {
       




		$red_name = $redis_x->get($dom.":name");
		$red_mem = number_format($redis_x->get($dom.":mem") / 1024 / 1024, 1);
		$red_cpu = $redis_x->get($dom.":cpu");
		$red_cpu_usage = $redis_x->get($dom.":cputime");
		$red_xml = $redis_x->get($dom.":xml");
		$red_state = $redis_x->get($dom.":state");
        
        $red_uuid = explode("vm:",$dom);
        $red_uuid = $red_uuid[1];
        
       	$vm_ip =$redis_x->get($dom.":ip");
		$vm_mac =$redis_x->get($dom.":mac"); 
		
        $but = "";
               
        switch($red_state) {
        	case '6':
        		$state = "CRASHED";
        		$state_img = "bug";
        		$but .= "<input type='submit' name='action' value='reboot'>";
        		$but .= "<input type='submit' name='action' value='destroy'>";
        		break;

        	case '5':
        		$state = "SHUTOFF";
        		$state_img = "shutdown";
				$but .= "<input type='submit' name='action' value='start'>";
         	    break;

        	case '4':
        		$state = "SHUTDOWN";
        		$state_img = "shutdown";
				$but .= "<input type='submit' name='action' value='start'>";
        		break;

        	case '3':
        		$state = "PAUSED";
        		$state_img = "paused";
				$but .= "<input type='submit' name='action' value='resume'>";
        		$but .= "<input type='submit' name='action' value='destroy'>";				
        		break;

        	case '2':
        		$state = "BLOCKED";
        		$state_img = "bug";
        		$but .= "<input type='submit' name='action' value='destroy'>";        		
        		break;

        	case '1':
        		$state = "RUNNING";
        		$state_img = "running";
        		$but .= "<input type='submit' name='action' value='pause'>";
        		$but .= "<input type='submit' name='action' value='shutdown'>";
        		$but .= "<input type='submit' name='action' value='reboot'>";
        		$but .= "<input type='submit' name='action' value='destroy'>";
        		break;
        		
        	case '0':
        		$state = "VIR_DOMAIN_NOSTATE";
        		$state_img = "bug";
        		$but .= "<input type='submit' name='action' value='destroy'>";
        		break;
        		       		
        	default:
        		$state = "UNKNOWN (".$state.")";
        		$but .= "<input type='submit' name='action' value='destroy'>";
        		
        }	

        $out = "<div style='vmdivcontainer'><h1><img style='margin-left: 10px;margin-top: 10px;' height='35px' src='theme/images/".$state_img.".png'>&nbsp;&nbsp;".$red_name."</h1>";
        
        /*
    	$out .= "<table style='float: left; margin-top: -50px; margin-left: 150px; border: 0;'><tr>";
		$out .= "<tr><td><div style='padding-left: 12px;'><img height='25px' src='theme/images/cpu.png'></div></td></tr>";
		$out .= "<tr><td>&nbsp;&nbsp;<div class='indicator_cpu'><div style='width:".number_format($red_cpu_usage, 0)."%;'></div>".$red_cpu." x CPU [".number_format($red_cpu_usage, 1)."%]</div></td></tr>";
        $out .= "</tr></table>";        
   	    */
		
		$out .= "<table style='float: left; margin-top: -50px; margin-left: 120px; border: 0;'>";
    	$out .= "<tr><td><img height='25px' src='theme/images/cpu.png'></td><td>".$red_cpu." vCPU(s) - [".number_format($red_cpu_usage, 1)."%]</td></tr>";
    	$out .= "<tr><td colspan='2'>&nbsp;</td></tr>";
  		$out .= "<tr><td colspan='2'><div class='indicator_cpu'><div style='width:".number_format($red_cpu_usage, 0)."%;'></div></div></td></tr>";
        //$out .= "</table>";        
 		//$out .= "<table style='float: left; margin-top: -5px; margin-left: -150px; border: 0;'>";
        $out .= "<tr><td><img height='25px' src='theme/images/ram.png'></td><td>".$red_mem." GB vRAM &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td></tr>";
		$out .= "<tr><td colspan='2'>&nbsp;</td></tr>";
		
		// MEM NOT WORKING 
		if($red_state == 1) {
			$ram = rand(95,99);
		} else {
			$ram = 0;
		}
		
  		$out .= "<tr><td colspan='2'><div class='indicator_ram'><div style='width:".$ram."%;'></div></div></td></tr>";
        $out .= "</table><br/><br/>";
		
		
		// DISK(s)	
		$out .= "<table style='float: left; margin-top: -77px; margin-left: 10px; border: 0;'>";
	
		$disk=array();
		$n=0;
		while($nn=1) {
			$c = $redis_x->get($dom.":disk_".$n.":type");
			if($c != "") {
			
				$disk[$n]["type"] = $redis_x->get($dom.":disk_".$n.":type");
				$disk[$n]["source"] = $redis_x->get($dom.":disk_".$n.":source");
				$disk[$n]["device"] = $redis_x->get($dom.":disk_".$n.":device");
				$disk[$n]["target"] = $redis_x->get($dom.":disk_".$n.":target");
				 
			
				$n=$n+1;
			} else {
			break;
			}
		}
		
		foreach($disk as $dis) {
			if($dis["type"] == "cdrom") $ico = "iso";
			if($dis["type"] == "disk") $ico = "hdd";
			if(!isset($dis["source"]) OR $dis["source"] == "") $dis["source"] = "&nbsp;none";
			if(strlen($dis["source"]) > 42) $dis["source"] = substr($dis["source"], 0, 42)."...";
			$out .= "<tr><td><img height='25px' src='theme/images/".$ico.".png'></td><td> [".$dis["device"]."]  ".$dis["source"]." </td></tr>";
			$out .= "<tr><td>&nbsp;</td></tr>";
		}
		$out .= "</table>";


				
		// NETDEV(s)	
		$out .= "<table style='float: left; margin-top: -50px; margin-left: 5px; border: 0;'>";
		
		$netdev=Array();
		$n=0;
		while($nn=1) {
			$c = $redis_x->get($dom.":netdev_".$n.":mac");
			if($c != "") {
			
				$netdev[$n]["ip"] = $redis_x->get($dom.":netdev_".$n.":ip");
				$netdev[$n]["mac"] = $redis_x->get($dom.":netdev_".$n.":mac"); 
			
				//RX/TX
				$netdev[$n]["rx_rate"] = $redis_x->get("vm:".$red_uuid.":netdev_".$n.":rx_rate");
				$netdev[$n]["tx_rate"] = $redis_x->get("vm:".$red_uuid.":netdev_".$n.":tx_rate");
				//UTIL
				$netdev[$n]["rx_util"] = $redis_x->get("vm:".$red_uuid.":netdev_".$n.":rx_util");
				$netdev[$n]["tx_util"] = $redis_x->get("vm:".$red_uuid.":netdev_".$n.":tx_util");
	
				$n=$n+1;
			} else {
			break;
			}
		}
		foreach($netdev as $net) {
			
			/*
			$out .= "<tr><td colspan='3'><img height='25px' src='theme/images/eth.png'> ".$net["ip"]." [".$net["mac"]."]</td></tr>";
			$out .= "<tr><td colspan='3'>&nbsp;</td></tr>";
			$out .= "<tr><td colspan='2'><div class='indicator_net'><div style='width:".$net["rx_util"]."%;'></div></div></td><td>".$net["rx_rate"]."</td></tr>";
        	$out .= "<tr><td colspan='2'><div class='indicator_net'><div style='width:".$net["tx_util"]."%;'></div></div></td><td>".$net["tx_rate"]."</td></tr>";
        	*/
        	
        	$out .= "<tr><td colspan='3'><img height='25px' src='theme/images/eth.png'> ".$net["ip"]." [".$net["mac"]."]</td></tr>";
			$out .= "<tr><td colspan='3'><div style='float: left; margin-left: 30px; margin-top: -10px;'>tx: <b>".$net["tx_rate"]."</b> rx: <b>".$net["rx_rate"]."</b></div><div class='indicator_net_rx'><div style='width:".$net["rx_util"]."%;'></div></div>&nbsp;";
        	$out .= "<div class='indicator_net_tx'><div style='width:".$net["tx_util"]."%;'></div></div></td></tr>";
        	$out .= "<tr><td colspan='3'></td></tr>";
			
        }
		$out .= "</table><br/><br/>";
		

		//$xml = base64_decode($red_xml);
		//$out .= "<p style='float: right; margin-top: -190px; margin-right: 2px;'>";
		//$out .= "<textarea cols='45' rows='13'>".print_r($netdev)."</textarea>";
		//$netdev0_ip = $redis_x->get($dom.":netdev_0:ip");
		//$netdev0_mac = $redis_x->get($dom.":netdev_0:mac"); 
		//$out .= "<textarea cols='45' rows='13'>IP:".$netdev0_ip." MAC:".$netdev0_mac."</textarea>";
		//$out .= "<textarea cols='45' rows='13'>".$xml."</textarea>";
		//$out .= "</p>";


		/*
		$xml_p = $redis_x->get($dom.":xml_p");
		$xml_p = base64_decode($xml_p);
		$out .= "<p style='float: right; margin-top: -190px; margin-right: 2px;'>";
		//$out .= "yoyo";	
		
		$out .= "<textarea cols='45' rows='13'>".$xml_p."</textarea>";
		$out .= "</p>";
		*/
		
		

		//$out .= "<hr/>";
		//$out .= "<p>";
		
		$out .= "<div style='float: right; margin-top: -18px; margin-right: 5px;'>";
		$out .= "<form method='POST' action='/?m=vm'>";
		$out .= "<input type='hidden' name='UUID' value='".$red_uuid."'>";
        $out .= "&nbsp;&nbsp;&nbsp;".$but;
		$out .= "</form>";
		$out .= "</div><br/>";
		
		//$out .= "&nbsp;";
		//$out .= "</p>";
		
        $out .= "</div>";
        
        
        $arr[$state][] = $out;
        
        
    	unset($img);
    	unset($red_cpu_usage);
    	
    
    }



$time_c = microtime();

if(isset($arr['RUNNING']) && count($arr['RUNNING'])) {

 sort($arr['RUNNING']);
 foreach($arr['RUNNING'] as $vm) {
	print_r($vm);
 }
}

if(isset($arr['PAUSED']) && count($arr['PAUSED'])) {

 sort($arr['PAUSED']);
 foreach($arr['PAUSED'] as $vm) {
	print_r($vm);
 }
}

if(isset($arr['SHUTOFF']) && count($arr['SHUTOFF'])) {

 sort($arr['SHUTOFF']);
 foreach($arr['SHUTOFF'] as $vm) {
	print_r($vm);
 }
}

//print_r($arr);

print "time: ".number_format(($time_c - $time_s), 2)."s";
?>
</ul></vmlist>

<a href="vnc://10.10.0.7:5902">VNC TEST</a>

<br/>
<br/>
<br/>
<br/>
<br/>

<?php
ob_end_flush();
?>
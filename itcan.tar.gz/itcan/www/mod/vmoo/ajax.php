
<?php

$time_s = microtime();
error_reporting(E_ALL); 
ini_set("display_errors", 1); 

// LIBVIRT
include("../../lib/libvirt.php");

if(isset($_POST["action"]) && isset($_POST["UUID"])) {
	$libvirt = new libvirt($_POST["UUID"]);
			
	switch($_POST["action"]) {
		case 'reboot':
		$libvirt->reboot();
		print "REBOOT VM: ".$libvirt->uuid;
		break;
		
		case 'stop':
		$libvirt->shutdown();
		print "SHUTDOWN VM: ".$libvirt->uuid;
		break;
		
		case 'destroy':
		$libvirt->destroy();
		print "FORCED SHUTDOWN VM: ".$libvirt->uuid;
		break;
		
		case 'start':
		$libvirt->start();
		print "STARTED VM: ".$libvirt->uuid;
		break;
	
	}
	usleep(2500000);
}

// REDIS
include("../../lib/predis.php");

$configurations = array(
    'host'     => '127.0.0.1', 
    'port'     => 6379, 
    'database' => 1
);

$redis = Predis_Client::create($configurations);
    
    
$domains = $redis->keys("vm:*");


        
        
    print "<vmlist><ul>";
    
    foreach ($domains as $dom)
    {
       

$configurations_x = array(
    'host'     => '127.0.0.1', 
    'port'     => 6379, 
    'database' => 2
);

$redis_x = Predis_Client::create($configurations_x);

		$red_name = $redis_x->get($dom.":name");
		$red_mem = number_format($redis_x->get($dom.":mem") / 1024 / 1024, 1);
		$red_cpu = $redis_x->get($dom.":cpu");
		$red_cpu_usage = $redis_x->get($dom.":cputime");
		$red_xml = $redis_x->get($dom.":xml");
		$red_state = $redis_x->get($dom.":state");
        
        $red_uuid = explode("vm:",$dom);
        $red_uuid = $red_uuid[1];
        
       	$vm_ip =$redis_x->get($dom.":ip");
		$vm_mac =$redis_x->get($dom.":mac"); 
		
        $but = "";
               
        switch($red_state) {
        	case '6':
        		$state = "CRASHED";
        		$but .= "<input type='submit' name='action' value='reboot'>";
        		$but .= "<input type='submit' name='action' value='destroy'>";
        		break;

        	case '5':
        		$state = "SHUTOFF";
				$but .= "<input type='submit' name='action' value='start'>";
         	    break;

        	case '4':
        		$state = "SHUTDOWN";
        		$img = "shutdown.png";
				$but .= "<input type='submit' name='action' value='start'>";
        		break;

        	case '3':
        		$state = "PAUSED";
				$but .= "<input type='submit' name='action' value='resume'>";
        		$but .= "<input type='submit' name='action' value='destroy'>";				
        		break;

        	case '2':
        		$state = "BLOCKED";
        		$but .= "<input type='submit' name='action' value='destroy'>";        		
        		break;

        	case '1':
        		$state = "RUNNING";
        		$but .= "<input type='submit' name='action' value='stop'>";
        		$but .= "<input type='submit' name='action' value='reboot'>";
        		$but .= "<input type='submit' name='action' value='destroy'>";
        		break;
        		
        	case '0':
        		$state = "VIR_DOMAIN_NOSTATE";
        		$but .= "<input type='submit' name='action' value='destroy'>";
        		break;
        		       		
        	default:
        		$state = "UNKNOWN (".$state.")";
        		$but .= "<input type='submit' name='action' value='destroy'>";
        		
        }	

        $out = "<li><h1><img style='margin-left: 10px;margin-top: 10px;' height='35px' src='theme/images/".$red_state.".png'>&nbsp;&nbsp;".$red_name."</h1>";
        $out .= "<p>";

        
    	$out .= "&nbsp;&nbsp;&nbsp;".$red_cpu." vCPU(s) - [".number_format($red_cpu_usage, 1)."%]<br/>";
        $out .= $red_mem." GB vRAM<br/>";
        $out .= "&nbsp;&nbsp;IP: ".$vm_ip." [".$vm_mac."]<br/>";
        
        //print "<textarea cols='100' rows='20'>".$red_xml."</textarea>";

		$out .= "<hr/>";
		
		$out .= "<form method='POST' action='/?m=vm'>";
		$out .= "<input type='hidden' name='UUID' value='".$red_uuid."'>";
        $out .= "&nbsp;&nbsp;&nbsp;".$but;
		$out .= "</form>";
		
        $out .= "</p></li>";
        
        
        $arr[$state][] = $out;
        
        
    	unset($img);
    	unset($red_cpu_usage);
    	
    
    }



$time_c = microtime();


foreach($arr['RUNNING'] as $vm) {
	print_r($vm);
}


foreach($arr['SHUTOFF'] as $vm) {
	print_r($vm);
}

//print_r($arr);

print $time_c - $time_s;
?>
</ul></vmlist>
<div id="form_box">
	<ul>
		<li><a id="start" href="#">start</a></li>
		<li><a id="stop" href="#">stop</a></li>
	</ul>
</div>
<div id="log">
	<div id="log_res"><!-- spanner --></div>
</div>

<br/>
<br/>
<br/>
<br/>
<br/>
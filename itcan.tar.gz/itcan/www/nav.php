<?php

//if(!isset($_GET["m"])) $_GET["m"] = "home";

if($_GET["m"] != "") { 
if(isset($mods)) unset($mods);

$mods[] = "home";
$mods[] .= "vm";
$mods[] .= "pxe";
$mods[] .= "image";
$mods[] .= "nfs";
$mods[] .= "cli";
$mods[] .= "fm";


$n=1;
foreach($mods as $m) {
	if($_GET["m"] == $m OR ($_GET["m"] == "" && $m == "main")) $c = " id='current'";
	
	print "<li><a href='".$m."' ".@$c.">".$m."</a></li>";
	unset($c);
}

print "<li style='float: right;'><a href='?m=logout'>logout</a></li>";

} else {

print "<li>&nbsp;</li>";
}
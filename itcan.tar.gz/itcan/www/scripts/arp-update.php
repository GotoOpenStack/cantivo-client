<?php

exec("/bin/nice -n 19 /usr/sbin/fping -q -c 1 -g 10.10.0.0/24 > /dev/null &");

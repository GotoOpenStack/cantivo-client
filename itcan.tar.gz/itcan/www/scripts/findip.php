<?php
$mac = strtoupper("52:54:00:02:5f:4d");

$cmd = "/sbin/arp -a -n|grep '".$mac."'\n";

$x = exec($cmd);


//print_r($x);
if($x != "") {
$xx = explode("(",$x);
$xxx = explode(")",$xx[1]);
print "MAC: ".$mac."\n";
print " IP: ".$xxx[0]."\n";

}


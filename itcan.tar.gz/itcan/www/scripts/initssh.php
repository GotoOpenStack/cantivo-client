#!/usr/bin/php
<?php
include_once("../lib/predis.php");
include_once("../lib/bootvm.php");


if(isset($_SERVER['argv'][1]) && isset($_SERVER['argv'][2])) {

$user = trim($_SERVER['argv'][1]);
$host = trim($_SERVER['argv'][2]);

system("sh initssh.sh ".$user." ".$host);

$bootvm = new bootvm();

$key = $bootvm->save($user,$host);

echo "hostkey is: ".$key;


} else {

echo "usage: initssh <user> <ipaddr>\n";

}

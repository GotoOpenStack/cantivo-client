#!/bin/sh

if [ ! -d /root/.ssh/ ] 
then
 echo "creationg directory /root/.ssh"
 mkdir -p /root/.ssh/
 echo "done."
fi

if [ ! -f /root/.ssh/id_rsa.pub ]
then
 echo "generating ssh public key..."
 ssh-keygen -t rsa -f /root/.ssh/id_rsa -N ''
 echo "done."
fi

if [ ! $1 ]
then
 echo "usage: initssh.sh <user> <ipaddr>"
else
 echo "initializing host: $2"

 #pass 1
 cat /root/.ssh/id_rsa.pub | ssh $1@$2 'cat > ~/id_rsa.pub && mkdir -p ~/.ssh && cat ~/id_rsa.pub >> ~/.ssh/authorized_keys && rm ~/id_rsa.pub && sync'
 echo "testing user access.."
 ssh $1@$2 "echo 'server says: great success!'"
 echo "user access..ok"

 echo "password (yes..again):"
 ssh -t $1@$2 '/usr/bin/sudo passwd root'
 echo "root password (hopefully) set.."

 echo "enabling passwordless root access..."
 cat /root/.ssh/id_rsa.pub | ssh root@$2 'cat > ~/id_rsa.pub && mkdir -p ~/.ssh && cat ~/id_rsa.pub >> ~/.ssh/authorized_keys && rm ~/id_rsa.pub && sync'
 echo "done.."

 echo "testing root access.."
 ssh root@$2 "echo 'server says: great success!'"
 echo "all done!"

fi
















#
#HERE BE DRAGONS
#
#'-i su&&cat id_rsa.pub >> /root/.ssh/authorized_keys && rm id_rsa.pub && sync '
#cat /root/.ssh/id_rsa.pub | ssh -t -t $1 'cat > id_rsa.pub && /bin/echo "$2" | /usr/bin/sudo -C3 -u root mkdir -p /root/.ssh/ &&/bin/echo "$2" | /usr/bin/sudo -C3 -u root cat id_rsa.pub >> /root/.ssh/authorized_keys && mkdir -p ~/.ssh && cat id_rsa.pub >> ~/.ssh/authorized_keys'
#cat /root/.ssh/id_rsa.pub | ssh -t root@$1 "cat > /tmp/id_rsa.pub && mkdir -p /root/.ssh/ && cat /tmp/id_rsa.pub >> /root/.ssh/authorized_keys && rm /tmp/id_rsa.pub && sync "
#scp /root/.ssh/id_rsa.pub root@$1:/tmp/id_rsa.pub
#ssh root@$1 "mkdir -p /root/.ssh/ && cat /tmp/id_rsa.pub >> /root/.ssh/authorized_keys && rm /tmp/id_rsa.pub && sync"
#

#
#useless, the other way around..
#
#ssh root@10.10.0.10 "ssh-keygen -t rsa -f /root/.ssh/id_rsa -N ''"
#scp root@10.10.0.10:/root/.ssh/id_rsa.pub /tmp/id_rsa.pub
#cat /tmp/id_rsa.pub >> /root/.ssh/authorized_keys
#rm /tmp/id_rsa.pub
#echo "done..\n";
#

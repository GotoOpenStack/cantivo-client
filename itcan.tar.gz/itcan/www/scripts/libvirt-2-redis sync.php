<?php

$time_s = microtime();

error_reporting(E_ALL); 
ini_set("display_errors", 1); 
 
// REDIS
include("../lib/predis.php");

$configurations_x = array(
    'host'     => '127.0.0.1', 
    'port'     => 6379, 
    'database' => 1
);

$configurations_m = array(
    'host'     => '127.0.0.1', 
    'port'     => 6379, 
    'database' => 2
);

$redis_m = Predis_Client::create($configurations_m);
$redis_x = Predis_Client::create($configurations_x);


// LIBVIRT
include("../lib/libvirt.php");

$libvirt = new libvirt();
$libvirt->connect();

$hostname=$libvirt->get_hostname();
$info=$libvirt->node_get_info();
 
$libvirt->list_domains();
    
    foreach ($libvirt->domains as $dom)
    {
		$libvirt->dom = $dom;
		$dominfo=$libvirt->domain_get_info();
    	$uuid=$libvirt->domain_get_uuid_string();

		$xml=$libvirt->domain_get_xml_desc();
		$netcfg = $libvirt->parsexmldom($xml);
		
		$redis_x->set("vm:".$uuid, $dominfo['state']);

		$redis_m->set("vm:".$uuid.":name", $libvirt->domain_get_name());
		$redis_m->set("vm:".$uuid.":mem", $dominfo['memory']);
		$redis_m->set("vm:".$uuid.":cpu", $dominfo['nrVirtCpu']);
		$redis_m->set("vm:".$uuid.":state", $dominfo['state']);
		$redis_m->set("vm:".$uuid.":xml", $xml);
		$redis_m->set("vm:".$uuid.":mac", $netcfg["mac"]);
		$redis_m->set("vm:".$uuid.":ip", $netcfg["ip"]);
		
	}

$time_c = microtime();
echo $time_c - $time_s;







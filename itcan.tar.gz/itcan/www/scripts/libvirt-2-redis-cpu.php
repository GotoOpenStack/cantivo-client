<?php
error_reporting(E_ALL); 
ini_set("display_errors", 1); 

exec("nice -n 19 php -q arp-update.php&");
sleep(5);
exec("nice -n 19 php -q libvirt-2-redis-sync.php&");

// REDIS
include("../lib/predis.php");

$configurations = array(
    'host'     => '127.0.0.1', 
    'port'     => 6379, 
    'database' => 3
);

$redis = Predis_Client::create($configurations);

$configurations_m = array(
    	'host'     => '127.0.0.1', 
    	'port'     => 6379, 
    	'database' => 2
);

$redis_m = Predis_Client::create($configurations_m);


// LIBVIRT
include("../lib/libvirt.php");

$libvirt = new libvirt();
$libvirt->connect();

$n=1;

while($n) {

$time_s = microtime(true);
$libvirt->list_domains();
    
    foreach ($libvirt->domains as $dom)
    {
	$libvirt->dom = $dom;
    $uuid = $libvirt->domain_get_uuid_string();
	$dominfo=$libvirt->domain_get_info();
	
	// ADD NEW SAMPLE DATA
    $cputime = gettimeofday(2)."|".$dominfo['cpuUsed'];
	$redis->lpush($uuid, $cputime);

	// CALCULATE FOR NOW() FROM RANGE
	$cputime_r = $redis->lrange($uuid, 0, 1);
	$s1 = explode("|",$cputime_r[0]);
	$s2 = explode("|",$cputime_r[1]);	
	$diff = $s1[1] - $s2[1];	
	$total = (1000 * $diff) / (2.5 * $dominfo['nrVirtCpu'] * 10^9);
	if($total > 100) $total = 100;
	
	// UPDATE CPUTIME
	$update = $redis_m->set("vm:".$uuid.":cputime",$total);
	$update = $redis_m->set("vm:".$uuid.":state",$dominfo['state']);

	// FINALLY PRUNE OLD DATA AND EXIT
	$trim = $redis->ltrim($uuid, 0, 1);

	}


$time_t = microtime(true) - $time_s;

//exec("php -q redis-cpu-2-arr.php");

echo "total runtime: ".$time_t."\n";

$n++;
if($n == 30) {
	print "##########ARP PROBE##########";
	exec("php -q arp-update.php&");
	sleep(2);
	print "##########LIBVIRT SYNC#######";
	exec("nice -n 19 php -q libvirt-2-redis-sync.php&");
	$n = 1;	
}

usleep(2500000);

}









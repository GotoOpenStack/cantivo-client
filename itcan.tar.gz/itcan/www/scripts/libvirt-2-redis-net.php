<?php
error_reporting(E_ALL); 
ini_set("display_errors", 1); 

$debug=false;
// REDIS
include("../lib/predis.php");

$configurations = array(
    'host'     => '127.0.0.1', 
    'port'     => 6379, 
    'database' => 4
);
$redis = Predis_Client::create($configurations);

$configurations_m = array(
    'host'     => '127.0.0.1', 
    'port'     => 6379, 
    'database' => 2
);
$redis_m = Predis_Client::create($configurations_m);


// LIBVIRT
include("../lib/libvirt.php");

$libvirt = new libvirt();
$libvirt->connect();

$n=1;

while($n) {

$time_s = microtime(true);
$libvirt->list_domains();
    
    foreach ($libvirt->domains as $dom)
    {
	$libvirt->dom = $dom;
    $dominfo=$libvirt->domain_get_info();
    $cfg = $libvirt->improved_parsexmldom($libvirt->domain_get_xml_desc());
    
    

    $nn=0;
    foreach($cfg->netdev as $netdev) {

		//CURRENT DEV
    	$dev = "netdev_".$nn;
    	
    	if($dominfo["state"] != 1) {
    	
    		$redis_m->set("vm:".$cfg->uuid.":".$dev.":rx_rate", "- bit/s");
    		$redis_m->set("vm:".$cfg->uuid.":".$dev.":tx_rate", "- bit/s");
    		$redis_m->set("vm:".$cfg->uuid.":".$dev.":rx_bytes", "0");
    		$redis_m->set("vm:".$cfg->uuid.":".$dev.":tx_bytes", "0");
    		
    	
    	} else {
    	
    	if(isset($netdev["target"])) {
    	//FETCH INFO FROM LIBVIRT
    	$netinfo = $libvirt->domain_interface_stats($netdev["target"]);

		//DEBUG
		if($debug) {
    	print "vm:".$cfg->uuid.":".$dev.":rx_bytes ".$netinfo["rx_bytes"]."\n";
    	print "vm:".$cfg->uuid.":".$dev.":rx_packets ".$netinfo["rx_packets"]."\n";
    	print "vm:".$cfg->uuid.":".$dev.":rx_errs ".$netinfo["rx_errs"]."\n";
    	print "vm:".$cfg->uuid.":".$dev.":rx_drop ".$netinfo["rx_drop"]."\n";
    	
    	print "vm:".$cfg->uuid.":".$dev.":tx_bytes ".$netinfo["tx_bytes"]."\n";
    	print "vm:".$cfg->uuid.":".$dev.":tx_packets ".$netinfo["tx_packets"]."\n";
    	print "vm:".$cfg->uuid.":".$dev.":tx_errs ".$netinfo["tx_errs"]."\n";
    	print "vm:".$cfg->uuid.":".$dev.":tx_drop ".$netinfo["tx_drop"]."\n";
    	
    	}
    	
    	
    	}
    	
    	// ADD NEW SAMPLE DATA
		$redis->lpush("vm:".$cfg->uuid.":".$dev.":rx_bytes", $netinfo["rx_bytes"]);
		$redis->lpush("vm:".$cfg->uuid.":".$dev.":rx_packets", $netinfo["rx_packets"]);
		$redis->lpush("vm:".$cfg->uuid.":".$dev.":rx_errs", $netinfo["rx_errs"]);
		$redis->lpush("vm:".$cfg->uuid.":".$dev.":rx_drop", $netinfo["rx_drop"]);

		$redis->lpush("vm:".$cfg->uuid.":".$dev.":tx_bytes", $netinfo["tx_bytes"]);
		$redis->lpush("vm:".$cfg->uuid.":".$dev.":tx_packets", $netinfo["tx_packets"]);
		$redis->lpush("vm:".$cfg->uuid.":".$dev.":tx_errs", $netinfo["tx_errs"]);
		$redis->lpush("vm:".$cfg->uuid.":".$dev.":tx_drop", $netinfo["tx_drop"]);


		$bw = "100";
		if($netdev["model"] == "virtio") $bw = "1000";
		if($netdev["model"] == "e1000") $bw = "1000";
		
		//$bw = $bw*1.28;
		
		// CALCULATE RX
		$rx_range = $redis->lrange("vm:".$cfg->uuid.":".$dev.":rx_bytes", 0, 1);
		$rx_diff = ($rx_range[0] - $rx_range[1]) / 2.5;
		$redis_m->set("vm:".$cfg->uuid.":".$dev.":rx_rate", bits($rx_diff));
		if($debug) print "vm:".$cfg->uuid.":".$dev.":rx_r ".bits($rx_diff)."\n";
		
		$rx_util = number_format((($rx_diff/1000000)-($bw/1000000)), 1);
		if($rx_util <= 0) $rx_util = 0;
		if($debug) print "vm:".$cfg->uuid.":".$dev.":rx_util ".$rx_util."\n";
		//$redis_m->set("vm:".$cfg->uuid.":".$dev.":rx_util", $rx_util);
		$redis_m->set("vm:".$cfg->uuid.":".$dev.":rx_util", $rx_util);

		
		// CALCULATE TX
		$tx_range = $redis->lrange("vm:".$cfg->uuid.":".$dev.":tx_bytes", 0, 1);
		$tx_diff = ($tx_range[0] - $tx_range[1]) / 2.5;
		$redis_m->set("vm:".$cfg->uuid.":".$dev.":tx_rate", bits($tx_diff));
		if($debug) print "vm:".$cfg->uuid.":".$dev.":tx_rate ".bits($tx_diff)."\n";
		
		//$tx_util = number_format((($tx_diff/1000)-$bw), 0);
		$tx_util = number_format((($tx_diff/1000000)-($bw/1000000)), 1);
		if($tx_util <= 0) $tx_util = 0;
		if($debug) print "vm:".$cfg->uuid.":".$dev.":tx_util ".$tx_util."\n";
		//$redis_m->set("vm:".$cfg->uuid.":".$dev.":tx_util", $tx_util);
		$redis_m->set("vm:".$cfg->uuid.":".$dev.":tx_util", $tx_util);
		
		// FINALLY PRUNE OLD DATA 
		$trim = $redis->ltrim("vm:".$cfg->uuid.":".$dev.":rx_bytes", 0, 1);
		$trim = $redis->ltrim("vm:".$cfg->uuid.":".$dev.":rx_packets", 0, 1);
		$trim = $redis->ltrim("vm:".$cfg->uuid.":".$dev.":rx_errs", 0, 1);
		$trim = $redis->ltrim("vm:".$cfg->uuid.":".$dev.":rx_drop", 0, 1);
		//$trim = $redis->ltrim("vm:".$cfg->uuid.":".$dev.":rx_util", 0, 1);
		$trim = $redis->ltrim("vm:".$cfg->uuid.":".$dev.":tx_bytes", 0, 1);
		$trim = $redis->ltrim("vm:".$cfg->uuid.":".$dev.":tx_packets", 0, 1);
		$trim = $redis->ltrim("vm:".$cfg->uuid.":".$dev.":tx_errs", 0, 1);
		$trim = $redis->ltrim("vm:".$cfg->uuid.":".$dev.":tx_drop", 0, 1);
		//$trim = $redis->ltrim("vm:".$cfg->uuid.":".$dev.":tx_util", 0, 1);
    	}
    	
    	$nn=$nn+1;
    	}
    
    
    }
    

	


$time_t = microtime(true) - $time_s;

//exec("php -q redis-cpu-2-arr.php");

print "### total runtime: ".$time_t."\n";

$n++;
if($n == 30) {
	print "##########ARP PROBE##########";
	//exec("php -q arp-update.php&");
	//sleep(2);
	//print "##########LIBVIRT SYNC#######";
	//exec("nice -n 19 php -q libvirt-2-redis-sync.php&");
	$n = 1;	
}

usleep(2500000);

}









<?php
$time_s = microtime();

error_reporting(E_ALL); 
ini_set("display_errors", 1); 
 
// REDIS
include("../lib/predis.php");

$configurations_x = array(
    'host'     => '127.0.0.1', 
    'port'     => 6379, 
    'database' => 1
);

$configurations_m = array(
    'host'     => '127.0.0.1', 
    'port'     => 6379, 
    'database' => 2
);

$redis_m = Predis_Client::create($configurations_m);
$redis_x = Predis_Client::create($configurations_x);


// LIBVIRT
include("../lib/libvirt.php");

$libvirt = new libvirt();
$libvirt->connect();

$hostname=$libvirt->get_hostname();
$info=$libvirt->node_get_info();
 
$libvirt->list_domains();
    
    foreach ($libvirt->domains as $dom)
    {
		$libvirt->dom = $dom;
		$dominfo=$libvirt->domain_get_info();
    	$uuid=$libvirt->domain_get_uuid_string();
		$this_vm_name = $libvirt->domain_get_name();
		
		//if($dominfo['state'] == '1') print_r($libvirt->domain_interface_stats());
		//if($dominfo['state'] == '1') print_r($libvirt->domain_memory_stats());
	
		
		$xml=$libvirt->domain_get_xml_desc();
		
		$par = $libvirt->improved_parsexmldom($xml);

		$sxml = simplexml_load_string($xml);
		
  		//print_R($par);
		
		//print_r($arr);

		
		$netcfg = $libvirt->parsexmldom($xml);
		
		$redis_x->set("vm:".$uuid, $dominfo['state']);

		$redis_m->set("vm:".$uuid.":name", $this_vm_name);
		$redis_m->set("vm:".$uuid.":mem", $dominfo['memory']);
		$redis_m->set("vm:".$uuid.":cpu", $dominfo['nrVirtCpu']);
		$redis_m->set("vm:".$uuid.":state", $dominfo['state']);
		$redis_m->set("vm:".$uuid.":xml", base64_encode($xml));
		$redis_m->set("vm:".$uuid.":mac", $netcfg["mac"]);
		$redis_m->set("vm:".$uuid.":ip", $netcfg["ip"]);
		
		$n=0;
		foreach($par->netdev as $netdevs) {
			if(isset($netdevs["type"])) $redis_m->set("vm:".$uuid.":netdev_".$n.":type", $netdevs["type"]);
			if(isset($netdevs["mac"])) $redis_m->set("vm:".$uuid.":netdev_".$n.":mac", $netdevs["mac"]);
			if(isset($netdevs["model"])) $redis_m->set("vm:".$uuid.":netdev_".$n.":model", $netdevs["model"]);
			if(isset($netdevs["target"])) $redis_m->set("vm:".$uuid.":netdev_".$n.":target", $netdevs["target"]);
			if(isset($netdevs["mac"])) $redis_m->set("vm:".$uuid.":netdev_".$n.":ip", $libvirt->ip_from_mac($netdevs["mac"]));
			$n=$n+1;
		}

		$n=0;
		foreach($par->disk as $diskdev) {
			if(isset($diskdev["type"])) $redis_m->set("vm:".$uuid.":disk_".$n.":type", $diskdev["type"]);
			if(isset($diskdev["source"])) $redis_m->set("vm:".$uuid.":disk_".$n.":source", $diskdev["source"]);
			if(isset($diskdev["device"])) $redis_m->set("vm:".$uuid.":disk_".$n.":device", $diskdev["device"]);
			if(isset($diskdev["bus"])) $redis_m->set("vm:".$uuid.":disk_".$n.":bus", $diskdev["bus"]);
			if(isset($diskdev["driver"])) $redis_m->set("vm:".$uuid.":disk_".$n.":driver", $diskdev["driver"]);
			if(isset($diskdev["readonly"])) $redis_m->set("vm:".$uuid.":disk_".$n.":readonly", "true");
			$n=$n+1;
		}
		
		
		
	}
	
print "#### TIME: ";
print (microtime() - $time_s);
print "s ######### \n";






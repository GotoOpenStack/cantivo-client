<?php

$time_s = microtime();

error_reporting(E_ALL); 
ini_set("display_errors", 1); 
 
// REDIS
include("../lib/predis.php");

$configurations_x = array(
    'host'     => '127.0.0.1', 
    'port'     => 6379, 
    'database' => 1
);

$configurations_m = array(
    'host'     => '127.0.0.1', 
    'port'     => 6379, 
    'database' => 2
);




$redis_m = Predis_Client::create($configurations_m);
$redis_x = Predis_Client::create($configurations_x);



$uri="qemu:///system";
$credentials=Array(VIR_CRED_AUTHNAME=>"root",VIR_CRED_PASSPHRASE=>"n1ntend0");
$conn=libvirt_connect($uri,false,$credentials);
if ($conn==false)
{
    echo ("Libvirt last error: ".libvirt_get_last_error()."\n");
    exit;
}
else
{
    $hostname=libvirt_get_hostname($conn);
    $info = libvirt_node_get_info($conn);  
    $domains=libvirt_list_domains($conn);
    
    foreach ($domains as $dom)
    {

    $dominfo=libvirt_domain_get_info($dom);
    $uuid = libvirt_domain_get_uuid_string($dom);

	$redis_x->set("vm:".$uuid, $dominfo['state']);

	$redis_m->set("vm:".$uuid.":name", libvirt_domain_get_name($dom));
	$redis_m->set("vm:".$uuid.":mem", $dominfo['memory']);
	$redis_m->set("vm:".$uuid.":cpu", $dominfo['nrVirtCpu']);
	$redis_m->set("vm:".$uuid.":state", $dominfo['state']);
	$redis_m->set("vm:".$uuid.":xml", libvirt_domain_get_xml_desc($dom));

	}

}

$time_c = microtime();
echo $time_c - $time_s;







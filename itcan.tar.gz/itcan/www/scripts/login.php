<?php

function Authenticate($realm) 
{ 
 global $PHP_AUTH_USER; 
 global $PHP_AUTH_PW; 

 if(!isset($PHP_AUTH_USER)) 
 { 
  header("WWW-Authenticate: Basic realm=\"$realm\""); 
  header("HTTP/1.0 401 Unauthorized"); 

  return false; 
 } 
 else 
 { 
  if(($fh = popen("/var/www/html/scripts/spasswd", "w"))) 
  { 
   fputs($fh, "$PHP_AUTH_USER $PHP_AUTH_PW"); 
   $r = pclose($fh); 

   if(!$r) 
  }
 }

 header("WWW-Authenticate: Basic realm=\"$realm\""); 
 header("HTTP/1.0 401 Unauthorized"); 

 return false; 
} 

Authenticate("test3");


?>
yoooo


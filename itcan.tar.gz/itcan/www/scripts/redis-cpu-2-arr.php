<?php



error_reporting(E_ALL); 
ini_set("display_errors", 1); 
 
// REDIS
include("../lib/predis.php");

$configurations = array(
    'host'     => '127.0.0.1', 
    'port'     => 6379, 
    'database' => 13
);


$redis = Predis_Client::create($configurations);


$uri="qemu:///system";
$credentials=Array(VIR_CRED_AUTHNAME=>"root",VIR_CRED_PASSPHRASE=>"n1ntend0");
$conn=libvirt_connect($uri,false,$credentials);
if ($conn==false)
{
    echo ("Libvirt last error: ".libvirt_get_last_error()."\n");
    exit;
}
else
{
    $hostname=libvirt_get_hostname($conn);
    $info = libvirt_node_get_info($conn);  
    $domains=libvirt_list_domains($conn);
    
    foreach ($domains as $dom)
    {


    $dominfo=libvirt_domain_get_info($dom);
    $uuid = libvirt_domain_get_uuid_string($dom);

	//print $uuid;

	$cputime = $redis->lrange($uuid, 0, 1);
	//print_r($redis->lrange($uuid, 0, 1));
	
	$s1 = explode("|",$cputime[0]);
	$s2 = explode("|",$cputime[1]);
	
	$diff = $s1[1] - $s2[1];
	
	//print $diff;
	
	$total = 100 * $diff / (2 * 8 * 10^9);

	$trim = $redis->ltrim($uuid, 0, 1);
	
	$configurations_m = array(
    	'host'     => '127.0.0.1', 
    	'port'     => 6379, 
    	'database' => 15
	);

	$redis_m = Predis_Client::create($configurations_m);

	$update = $redis_m->set("vm:".$uuid.":cputime",$total);
	
	}

}




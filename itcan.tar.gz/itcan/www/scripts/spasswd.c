#include <unistd.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <crypt.h> 
#include <shadow.h> 

static char salt[12], user[128], pass[128]; 

void die(void) 
{ 
 memset(salt, '\0', 12); 
 memset(user, '\0', 128); 
 memset(pass, '\0', 128); 
} 

int main(int argc, char *argv[]) 
{ 
 struct spwd *passwd; 

 atexit(die); die(); 

 if(fscanf(stdin, "%127s %127s", user, pass) != 2) 
  return 1; 

 if(!(passwd = getspnam(user))) 
  return 1; 

 strncpy(salt, passwd->sp_pwdp, 11); 
 strncpy(pass, crypt(pass, salt), 127); 

 if(!strncmp(pass, passwd->sp_pwdp, 127)) {
  printf("err..");
  return 0; 
 }

 printf("yey!");
 return 1; 
} 

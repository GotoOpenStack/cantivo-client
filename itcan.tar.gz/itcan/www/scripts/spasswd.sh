gcc -O2 -s -o spasswd -lcrypt spasswd.c

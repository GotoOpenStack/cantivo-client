#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <pwd.h>
#include <grp.h>
#include <string.h>
#include <shadow.h>
//#include <userpw.h>

int main()
{
// -------------------------- //
// ------- passwd file ------ //
// -------------------------- //
FILE* fp;
struct passwd *p;

memset(&p, 0, sizeof(p));

if (!(fp = fopen("/etc/passwd", "r"))) {
perror("Problem ");
return(1);
}

// --------------------------- //
// ------ shadow file -------- //
// --------------------------- //

FILE* fps;

struct spwd *sp;
//char currpass[255];
memset(&sp, 0, sizeof(sp));
//memset(&currpass, 0, sizeof(currpass)); 
if (!(fps = fopen("/etc/shadow", "r+"))) {
perror("Problem");
return(1);
}



char user[20] = "kalle";
//strcpy(sp->sp_pwdp,t);
//char password[10] = "password"; 

/* Loop thru passwd file */

while ((sp = getspent()) != NULL) {
if (strcmp(sp->sp_namp,user) == 0 ) {
//if(!(sp=getspnam(sp->sp_namp))) {
// printf("that user does not exist in shadow file\n");
//} else {
strcpy(sp->sp_pwdp,"testpass");
putspent(sp, fps);
}

else {
//strcpy(sp->sp_pwdp,"temp");
putspent(sp,fps);
}
}
fclose(fp);
fclose(fps); return( EXIT_SUCCESS );
}

exit(0);

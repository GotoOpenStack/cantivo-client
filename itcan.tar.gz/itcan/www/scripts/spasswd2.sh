gcc -O2 -s -o spasswd2 -lcrypt spasswd2.c

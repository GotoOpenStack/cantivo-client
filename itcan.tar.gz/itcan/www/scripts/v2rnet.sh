#!/bin/sh
cd /var/www/html/scripts/
nice -n 19 /usr/bin/php -q libvirt-2-redis-net.php
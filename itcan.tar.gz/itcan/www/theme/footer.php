<br/>
<br/>
<footer>
   <!-- REPEAT MENU -->		
	<ul>
		<?php include("nav.php"); ?> 
	</ul>
	<p>Adell Group &copy; 2010</p> 
</footer> 
</div> 

</body> 
</html>
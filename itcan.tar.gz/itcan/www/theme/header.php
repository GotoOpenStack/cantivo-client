<!DOCTYPE html> 
<html> 
<head> 
<title>ADELL VIRTUAL COMMANDER</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/> 
<link rel="stylesheet" href="theme/style.css.php" media="screen" type="text/css" /> 
<link rel="stylesheet" href="theme/print.css.php" media="print" type="text/css" /> 

<?php
if($_GET["m"] == "image") {
?>
<!--[if IE]><link rel="stylesheet" href="fancy2/mootools/ie.css" type="text/css" media="screen, projection"><![endif]--> 
<script type="text/javascript" src="js/jquery-min.js"></script>
<script type="text/javascript" src="js/mootools.js"></script>
<script type="text/javascript" src="js/Swiff.Uploader.js"></script>
<script type="text/javascript" src="js/Fx.ProgressBar.js"></script>
<script type="text/javascript" src="js/Lang.js"></script>
<script type="text/javascript" src="js/FancyUpload2.js"></script>


<!-- See script.js -->
<script type="text/javascript">
//<![CDATA[

/**
 * FancyUpload Showcase
 *
 * @license		MIT License
 * @author		Harald Kirschner <mail [at] digitarald [dot] de>
 * @copyright	Authors
 */

window.addEvent('domready', function() { // wait for the content

	// our uploader instance 
	
	var up = new FancyUpload2($('demo-status'), $('demo-list'), { // options object
		// we console.log infos, remove that in production!!
		verbose: true,
		
		// url is read from the form, so you just have to change one place
		url: $('form-demo').action,
		
		// path to the SWF file
		path: 'js/Swiff.Uploader.swf',
		
		// remove that line to select all files, or edit it, add more items
		typeFilter: {
			'Images (*.jpg, *.jpeg, *.gif, *.png, *.mkv, *.avi)': '*.jpg; *.jpeg; *.gif; *.png; *.mkv; *.avi'
		},
		
		// this is our browse button, *target* is overlayed with the Flash movie
		target: 'demo-browse',
		
		// graceful degradation, onLoad is only called if all went well with Flash
		onLoad: function() {
			$('demo-status').removeClass('hide'); // we show the actual UI
			$('demo-fallback').destroy(); // ... and hide the plain form
			
			// We relay the interactions with the overlayed flash to the link
			this.target.addEvents({
				click: function() {
					return false;
				},
				mouseenter: function() {
					this.addClass('hover');
				},
				mouseleave: function() {
					this.removeClass('hover');
					this.blur();
				},
				mousedown: function() {
					this.focus();
				}
			});

			// Interactions for the 2 other buttons
			
			$('demo-clear').addEvent('click', function() {
				up.remove(); // remove all files
				return false;
			});

			$('demo-upload').addEvent('click', function() {
				up.start(); // start upload
				return false;
			});
		},
		
		// Edit the following lines, it is your custom event handling
		
		/**
		 * Is called when files were not added, "files" is an array of invalid File classes.
		 * 
		 * This example creates a list of error elements directly in the file list, which
		 * hide on click.
		 */ 
		onSelectFail: function(files) {
			files.each(function(file) {
				new Element('li', {
					'class': 'validation-error',
					html: file.validationErrorMessage || file.validationError,
					title: MooTools.lang.get('FancyUpload', 'removeTitle'),
					events: {
						click: function() {
							this.destroy();
						}
					}
				}).inject(this.list, 'top');
			}, this);
		},
		
 				/**
                 * This one was directly in FancyUpload2 before, the event makes it
                 * easier for you, to add your own response handling (you probably want
                 * to send something else than JSON or different items).
                 */
                onFileSuccess: function(file, response) {
                        var json = new Hash(JSON.decode(response, true) || {});
                                        
                        if (json.get('status') == '1') {
                                file.element.addClass('file-success');
                                file.info.set('html', '<strong>Upload success:</strong> [' + json.get('width') + ' x ' + json.get('height') + 'px, <em>' + json.get('mime') + '</em>]');
                        } else {
                                file.element.addClass('file-failed');
                                file.info.set('html', '<strong>An error occured:</strong> ' + (json.get('error') ? (json.get('error') + ' #' + json.get('code')) : response));
                        }
                },
                           

		
		/**
		 * onFail is called when the Flash movie got bashed by some browser plugin
		 * like Adblock or Flashblock.
		 */
		onFail: function(error) {
			switch (error) {
				case 'hidden': // works after enabling the movie and clicking refresh
					alert('To enable the embedded uploader, unblock it in your browser and refresh (see Adblock).');
					break;
				case 'blocked': // This no *full* fail, it works after the user clicks the button
					alert('To enable the embedded uploader, enable the blocked Flash movie (see Flashblock).');
					break;
				case 'empty': // Oh oh, wrong path
					alert('A required file was not found, please be patient and we fix this.');
					break;
				case 'flash': // no flash 9+ :(
					alert('To enable the embedded uploader, install the latest Adobe Flash plugin.')
			}
		}
		
	});
	
});
		//]]>
	</script>
	<link rel="stylesheet" href="mod/image/upload.css" media="screen" type="text/css" /> 
<?php
} elseif($_GET["m"] == "vm") {
?>
<script type="text/javascript" src="js/mootools.js"></script>

<script language="javascript">
var request = new Request({
    url: 'mod/vm/ajax.php',
    method: 'get',
    update: 'refresh-me',
    onComplete: function(response) {
        $('vmdiv').set('html',response);
    }
})

var doRefresh = function() {
    request.send();
};

doRefresh.periodical(4000);
doRefresh();
</script>


<?php
} elseif($_GET["m"] == "vm2") {
?>
<script type="text/javascript" src="js/mootools.js"></script>

<script language="javascript">
var accordion = new Accordion('h3.atStart', 'div.atStart', {
	opacity: false,
	onActive: function(toggler, element){
		toggler.setStyle('color', '#ff3300');
	},
 
	onBackground: function(toggler, element){
		toggler.setStyle('color', '#222');
	}
}, $('accordion'));

var newTog = new Element('h3', {'class': 'toggler'}).setHTML('Common descent');
 
var newEl = new Element('div', {'class': 'element'}).setHTML('<p>A group of organisms is said to have common descent if they have a common ancestor. In biology, the theory of universal common descent proposes that all organisms on Earth are descended from a common ancestor or ancestral gene pool.</p><p>A theory of universal common descent based on evolutionary principles was proposed by Charles Darwin in his book The Origin of Species (1859), and later in The Descent of Man (1871). This theory is now generally accepted by biologists, and the last universal common ancestor (LUCA or LUA), that is, the most recent common ancestor of all currently living organisms, is believed to have appeared about 3.9 billion years ago. The theory of a common ancestor between all organisms is one of the principles of evolution, although for single cell organisms and viruses, single phylogeny is disputed</p>');
 
accordion.addSection(newTog, newEl, 0);
</script>

<?php
} elseif($_GET["m"] == "fm") {
?>
<script type="text/javascript" src="js/jquery-min.js"></script>
<script type="text/javascript" src="js/mootools-1.2.4-core.js"></script>

<script type="text/javascript" src="js/mootable.js"></script>
<script type="text/javascript" src="js/Window.js"></script>

<link rel="stylesheet" href="js/mootable.css" media="screen" type="text/css" /> 


<?php
}
?>

<!--[if IE]>
	<script src="/js/html5.js"></script>
<![endif]-->
</head>
<body id="home">
<div id="header-wrap"> 
	<header> 
		<a href="/"><img src="theme/images/logo.png" width="491" height="137" alt="Pelletized -- Ed Wheeler, web designer" /></a> 
		<nav>
			<ul id="navbar">
			<?php include("nav.php") ?>
			</ul>
		</nav> 
	</header> 
</div> 

<div id="page">

	

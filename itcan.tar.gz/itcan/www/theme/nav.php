<?php

if(!isset($_GET["m"])) $_GET["m"] = "home";

if(isset($mods)) unset($mods);

$mods[] = "home";
$mods[] .= "vm";
$mods[] .= "pxe";
$mods[] .= "image";
$mods[] .= "fm";
$n=1;
foreach($mods as $m) {
	if($_GET["m"] == $m OR ($_GET["m"] == "" && $m == "main")) $c = " id='current'";
	
	print "<li><a href='?m=".$m."' ".@$c.">".$m."</a></li>";
	unset($c);
}
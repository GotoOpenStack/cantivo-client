<?php
if(substr_count($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip')) {
 ob_start("ob_gzhandler");
} else {
 ob_start();
}

header("Content-type: text/css; charset: UTF-8");
header("Cache-Control: must-revalidate");
$offset = 3600 * 3600 ;
header("Expires: ".gmdate("D, d M Y H:i:s",time() + $offset)." GMT");

readfile("print.css");

ob_end_flush();
?>

      </div> 
      
      <?php 
      if(isset($_GET["debug"])) {
      ?>
      <div class='line center smallAir border dim'> 
        <div class='cmddiv alwaysHidden' id='notfound'> 
          
          <div class='line gapTop'> 
            <div class='unit'> 
              &gt;&nbsp;
            </div> 
            <h1 class='lastUnit command'> 
              abc
            </h1> 
          </div>
          
          <div class='gapLeft smallGapTop'> 
            <h2> 
              Command not found.
            </h2> 
          </div> 
          
          
        </div> 

       <div class='line gapTop' id='prompt'> 
          <div class='unit'> 
            &gt;&nbsp;
          </div> 
          <div class='unit command' id='command'></div> 
          <div class='bright unit' id='cursor'> 
            |
          </div> 
        </div> 
      </div> 
       <?php 
       }
       ?>
      
      <div class='foot smallAirTop bigAirBottom'> 
        <div class='unit size1of2 tag'> 
          <span style='font-size: 0.7em;'><?php $timer_stop = microtime(true);  print exec("uptime")." load time: ".number_format(($timer_stop - $timer_start), '2','.','.')." sec"; ?></span> 
          
        </div> 
        <div class='lastUnit size1of2 tag right'> 
          <span class='dim'>2010 &copy;</span> <a class='link' href='http://www.adell.no/' target="_blank">Adell Group</a> 
        </div> 
      </div> 
    </div> 
    
    
    
  </body> 
</html> 
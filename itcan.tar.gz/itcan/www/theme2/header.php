<!DOCTYPE html> 
<html> 
  <head> 
    <title> 
      <?php print $world->name." v".$world->ver; ?>
    </title> 
    <link href="theme2/nosql.css" rel='stylesheet' type='text/css' /> 
    <style type="text/css"> 
    img.c7 {margin: 0px 0px 0 30px;}
    img.c6 {margin: 0px 0px 0 150px;}
    p.c5 {padding: 0px; margin: 0px;}
    span.c4 {color: #ff9933;}
    div.c3 {position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;}
    iframe.c2 {width: 550px; height: 1300px; border: 0px none; background-color: #ffffff;}
    td.c1 {text-align: right;}
    </style>
    
    <?php 
    include("head.php");
    ?>
  </head> 
  <body> 
    <script type='text/javascript'> 
      document.write('<style type="text/css">.hidden { display: none }<\/style>');
    </script> 
    <div class='page narrow'> 
      <div class='head'> 
        <div class='line border'> 
          <div class='unit size1of2 logo border air'>          
<span class='brasil'>it</span><span class='sql'>can</span><span class='dim'>.</span>
<span style='font-size: 0.3em; margin-left: -23px;'>
<span class='dim'>&nbsp;</span><span class='no'>beta</span><span class='dim'></span>
</span>

          </div> 
          <div class='lastUnit size1of2 bigAirTop airLeft'> 
            <div class='line'> 
              <span class='command'>host</span> <span class='dim'>=</span> <span class='string'><?php print passthru('hostname'); ?></span> 
            </div> 
            <div class='line'> 
              <span class='command'>ip</span> <span class='dim'>=</span> <span class='string'><?php $x = explode(":",exec('ifconfig br0|grep "inet addr"')); $xx = explode(" ",$x[1]); print trim($xx[0]); ?></span> 
            </div> 
          </div> 
        </div> 
        <div class='line center smallAir border'> 
        
        <nav>
		<ul id="navbar">	
        <?php 
        include("nav.php");
        ?>
        </ul>
        </nav>
        
        </div> 
      </div> 
 <div class='body border bigAir'> 
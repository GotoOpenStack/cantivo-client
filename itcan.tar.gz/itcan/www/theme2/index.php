<!DOCTYPE html> 
<html> 
  <head> 
    <title> 
      ITCAN WEB
    </title> 
    <link href="nosql.css" rel='stylesheet' type='text/css' /> 
    <style type="text/css"> 
    img.c7 {margin: 0px 0px 0 30px;}
    img.c6 {margin: 0px 0px 0 150px;}
    p.c5 {padding: 0px; margin: 0px;}
    span.c4 {color: #ff9933;}
    div.c3 {position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;}
    iframe.c2 {width: 550px; height: 1300px; border: 0px none; background-color: #ffffff;}
    td.c1 {text-align: right;}
    </style> 
  </head> 
  <body> 
    <script type='text/javascript'> 
      document.write('<style type="text/css">.hidden { display: none }<\/style>');
    </script> 
    <div class='page narrow'> 
      <div class='head'> 
        <div class='line border'> 
          <div class='unit size1of2 logo border air'>          
<span class='brasil'>it</span><span class='sql'>can</span>
<span style='font-size: 0.3em; margin-left: -23px;'>
<span class='dim'>(</span><span class='no'>beta</span><span class='dim'>)</span><span class='dim'>.</span> 
</span>

          </div> 
          <div class='lastUnit size1of2 bigAirTop airLeft'> 
            <div class='line'> 
              <span class='command'>host</span> <span class='dim'>=</span> <span class='string'><?php print passthru('hostname'); ?></span> 
            </div> 
            <div class='line'> 
              <span class='command'>ip</span> <span class='dim'>=</span> <span class='string'><?php $x = explode(":",exec('ifconfig br0|grep "inet addr"')); $xx = explode(" ",$x[1]); print trim($xx[0]); ?></span> 
            </div> 
          </div> 
        </div> 
        <div class='line center smallAir border'> 
        
        <nav>
		<ul id="navbar">	
        <?php 
        include("../nav.php");
        ?>
        </ul>
        </nav>
        
        </div> 
      </div> 
      <div class='body border bigAir'> 
        <div id='ajuda'> 
          &gt; help
          <div class='gapLeft'> 
            <div class='dim'> 
              Commands available:
            </div> 
            
            <div class='line'> 
              <a class='command unit size1of4' href='#sobre'>home</a> 
              <div class='lastUnit size3of4'> 
                this menu
              </div> 
            </div> 
            
            <div class='line'> 
              <a class='command unit size1of4' href='?m=vm'>vm</a> 
              <div class='lastUnit size3of4'> 
                virtual machine(s) status & configuration
              </div> 
            </div> 
            
            
            
            <div class='line'> 
              <a class='command unit size1of4' href='#agenda'>agenda</a> 
              <div class='lastUnit size3of4'> 
                retorna a agenda do evento
              </div> 
            </div> 
            <div class='line'> 
              <a class='command unit size1of4' href='#register'>registro</a> 
              <div class='lastUnit size3of4'> 
                retorna detalhes sobre a inscri&ccedil;&atilde;o
              </div> 
            </div> 
            <div class='line'> 
              <a class='command unit size1of4' href='#palestrantes'>palestrantes</a> 
              <div class='lastUnit size3of4'> 
                retorna a lista de palestrantes
              </div> 
            </div> 
            <div class='line'> 
              <a class='command unit size1of4' href='#local'>local</a> 
              <div class='lastUnit size3of4'> 
                retorna a localiza&ccedil;&atilde;o do encontro
              </div> 
            </div> 
          </div> 
        </div> 
        <div id='commands'></div> 
        <div class='cmddiv hidden' id='sobre'> 
          <div class='line gapTop'> 
            <div class='unit'> 
              &gt;&nbsp;
            </div> 
            <h1 class='lastUnit command'> 
              sobre
            </h1> 
          </div> 
          <div class='gapLeft smallGapTop'> 
			<p> 
			  O movimento noSQL est&aacute; transformando completamente a forma com que as pessoas olham para os dados - empresas como Twitter, Facebook e Google s&atilde;o alguns dos usu&aacute;rios desta tecnologia.<br/> 
			  <br/> 
			  Os motivos que levam estas e outras empresas ao redor do mundo a utilizar um noSQL s&atilde;o variadas. Em geral, envolvem escalabidade e performance que n&atilde;o conseguimos obter com os tradicionais bancos de dados relacional.<br/> 
			  <br/> 
			  O noSQL Brasil &eacute; o primeiro encontro brasileiro que visa apresentar, promover e discutir as tecnologias &quot;noSQL&quot;. Para isso, ser&atilde;o realizadas palestras sobre as diversas abordagens noSQL com exemplos pr&aacute;ticos e demonstra&ccedil;&otilde;es, bem como um painel onde ser&aacute; discutido como e quando utilizar noSQL.<br/> 
			</p> 
          </div> 
        </div> 
        
        
        <div class='cmddiv hidden' id='vm'> 
          <div class='line gapTop'> 
            <div class='unit'> 
              &gt;&nbsp;
            </div> 
            <h1 class='lastUnit command'> 
              virtual machines
            </h1> 
          </div> 
          <div class='gapLeft smallGapTop'> 
            <p> 
            BANAN!
              	
            </p> 
          </div> 
          
          
          
        </div> 
        
        
        
        <div class='cmddiv hidden' id='agenda'> 
          <div class='line gapTop'> 
            <div class='unit'> 
              &gt;&nbsp;
            </div> 
            <h1 class='lastUnit command'> 
              agenda
            </h1> 
          </div> 
          <div class='gapLeft smallGapTop'> 
            <table> 
              <tbody> 
                <tr> 
                  <td class="sql" colspan="2"> 
                    S&aacute;bado, 15 de Maio de 2010
                  </td> 
                </tr> 
                <tr> 
                  <td valign="top" class="dim c1"> 
                    08.30
                  </td> 
                  <td> 
                    &nbsp;- Abertura <br/> &nbsp;&nbsp;&nbsp;&nbsp;<a class="command speaker" href="#palestrante/porcelli">Alexandre Porcelli</a>, <span class="brasil">OpenSpotLight</span> 
                  </td> 
                </tr> 
                <tr> 
                  <td valign="top" class="dim c1"> 
                    09.00
                  </td> 
                  <td> 
                    &nbsp;- Nas Nuvens com KVM, JBoss REST-Easy e InfiniSpan<br/>&nbsp;&nbsp;&nbsp;&nbsp;<a class="command speaker" href="#palestrante/edgar-silva">Edgar Silva</a> &amp; <a class="command speaker" href="#palestrante/samuel">Samuel Tauil</a>, <span class="brasil">Red Hat Brasil</span> 
                  </td> 
                </tr> 
                <tr> 
                  <td valign="top" class="dim c1"> 
                    10.00
                  </td> 
                  <td> 
                    &nbsp;- Performance e simplicidade com Chave/Valor utilizando REDIS<br/> &nbsp;&nbsp;&nbsp;&nbsp;<a class="command speaker" href="#palestrante/teston">Luiz Fernando Teston</a>, <span class="brasil">OpenSpotLight</span> 
                  </td> 
                </tr> 
                <tr> 
                  <td valign="top" class="dim c1"> 
                    10.50
                  </td> 
                  <td class="dim"> 
                    &nbsp;- Coffee break
                  </td> 
                </tr> 
                <tr> 
                  <td valign="top" class="dim c1"> 
                    11.00
                  </td> 
                  <td> 
                    &nbsp;- O papel do REST no Neo4J e CouchDB, um comparativo<br/> &nbsp;&nbsp;&nbsp;&nbsp;<a class="command speaker" href="#palestrante/guilherme">Guilherme Silveira</a>, <span class="brasil">Caelum</span> 
                  </td> 
                </tr> 
                <tr> 
                  <td valign="top" class="dim c1"> 
                    12.00
                  </td> 
                  <td class="dim"> 
                    &nbsp;- Almo&ccedil;o
                  </td> 
                </tr> 
                <tr> 
                  <td valign="top" class="dim c1"> 
                    13.30
                  </td> 
                  <td> 
                    &nbsp;- Divide et impera - Processamento massivo com Hadoop, Pig e HBase<br/> &nbsp;&nbsp;&nbsp;&nbsp;<a class="command speaker" href="#palestrante/vinicius">Vinicius Carvalho</a>, <span class="brasil">SambaTech</span> 
                  </td> 
                </tr> 
                <tr> 
                  <td valign="top" class="dim c1"> 
                    13.30
                  </td> 
                  <td> 
                    &nbsp;- Aguardando confirma&ccedil;&atilde;o<br/> &nbsp;&nbsp;&nbsp;&nbsp;<a class="command speaker" href="#palestrante/none">??????</a>, <span class="brasil">XXXXX</span> 
                  </td> 
                </tr> 
                <tr> 
                  <td valign="top" class="dim c1"> 
                    15.15
                  </td> 
                  <td class="dim"> 
                    &nbsp;- Coffee break
                  </td> 
                </tr> 
                <tr> 
                  <td valign="top" class="dim c1"> 
                    15.30
                  </td> 
                  <td> 
                    &nbsp;- Aguardando confirma&ccedil;&atilde;o<br/> &nbsp;&nbsp;&nbsp;&nbsp;<a class="command speaker" href="#palestrante/none">??????</a>, <span class="brasil">XXXXX</span> 
                  </td> 
                </tr> 
                <tr> 
                  <td valign="top" class="dim c1"> 
                    16.30
                  </td> 
                  <td> 
                    &nbsp;- Painel de Discuss&atilde;o
                  </td> 
                </tr> 
                <tr> 
                  <td valign="top" class="dim c1"> 
                    17.30
                  </td> 
                  <td> 
                    &nbsp;- Happy Hour!
                  </td> 
                </tr> 
              </tbody> 
            </table> 
            <p> 
                &nbsp;<br/> 
                (*) Esta agenda pode ser alterada sem aviso pr&eacute;vio.
            </p> 
          </div> 
        </div> 
        <div class='cmddiv hidden' id='register'> 
          <div class='line gapTop'> 
            <div class='unit'> 
              &gt;&nbsp;
            </div> 
            <h1 class='lastUnit command'> 
              registro
            </h1> 
          </div> 
          <div class='gapLeft smallGapTop'> 
            <p> 
              Apesar de ser um evento aberto e gratu&iacute;to para a comunidade, temos um n&uacute;mero limitado de vagas, portanto fa&ccedil;a j&aacute; seu registro e garanta sua vaga!
            </p> 
            <p> 
              &nbsp;
            </p> 
            <p> 
              <iframe src="http://spreadsheets.google.com/embeddedform?formkey=dE9zM2xCQ2xKZDItdXhXMHFDWFBRWUE6MQ" width="760" height="809" frameborder="0" marginheight="0" marginwidth="0">Loading...</iframe> 
            </p> 
          </div> 
        </div> 
        <div class='cmddiv hidden' id='local'> 
          <div class='line gapTop'> 
            <div class='unit'> 
              &gt;&nbsp;
            </div> 
            <h1 class='lastUnit command'> 
              local
            </h1> 
          </div> 
          <div class='gapLeft smallGapTop'> 
            <p class="sql"> 
              Acctiva - Audit&oacute;rio Principal 
            </p> 
            <p> 
              Av. Paulista, 1159 - 16o andar
            </p> 
            <p> 
              S&atilde;o Paulo
            </p> 
            <p> 
              S&atilde;o Paulo
            </p> 
            <p> 
              Brasil
            </p> 
            <p> 
              &nbsp;
            </p> 
            <p> 
              <a target="_blank" href="http://maps.google.com.br/maps?f=q&source=s_q&hl=pt-BR&q=Av.+Paulista,+1159+-+Bela+Vista,+S%C3%A3o+Paulo,+01311-200&sll=-23.636418,-46.735659&sspn=0.011952,0.017703&ie=UTF8&cd=2&geocode=FX1wmP4dyyA4_Q&split=0&hq=&hnear=Paulista+Avenue+-+Av.+Paulista+-+S%C3%A3o+Paulo&ll=-23.561057,-46.655824&spn=0.005979,0.008851&z=17"> 
              mapa</a> 
            </p> 
          </div> 
        </div> 
        <div class='cmddiv hidden' id='palestrantes'> 
          <div class='line gapTop'> 
            <div class='unit'> 
              &gt;&nbsp;
            </div> 
            <h1 class='lastUnit command'> 
              palestrantes
            </h1> 
          </div> 
          <div class='gapLeft smallGapTop'> 
            <h1 class="sql"> 
              Palestrantes
            </h1> 
            <p> 
              &nbsp;
            </p> 
            <p> 
              <a class="command speaker" href="#palestrante/porcelli">Alexandre Porcelli</a> 
              <span class="dim">(</span><span class="brasil">OpenSpotLight</span><span class=
              "dim">)</span> 
            </p> 
            <p> 
              <a class="command speaker" href="#palestrante/edgar-silva">Edgar Silva</a> 
              <span class="dim">(</span><span class="brasil">Red Hat Brasil</span><span class=
              "dim">)</span> 
            </p> 
            <p> 
              <a class="command speaker" href="#palestrante/samuel">Samuel Tauil</a> 
              <span class="dim">(</span><span class="brasil">Red Hat Brasil</span><span class=
              "dim">)</span> 
            </p> 
            <p> 
              <a class="command speaker" href="#palestrante/teston">Luiz Fernando Teston</a> 
              <span class="dim">(</span><span class="brasil">OpenSpotLight</span><span class=
              "dim">)</span> 
            </p> 
            <p> 
              <a class="command speaker" href="#palestrante/vinicius">Vinicius Carvalho</a> 
              <span class="dim">(</span><span class="brasil">SambaTech</span><span class=
              "dim">)</span> 
            </p> 
            <p> 
              <a class="command speaker" href="#palestrante/guilherme">Guilherme Silveira</a> 
              <span class="dim">(</span><span class="brasil">Caelum</span><span class=
              "dim">)</span> 
            </p> 
            <p> 
                &nbsp;<br/> 
                (*) A lista de palestrantes pode ser alterada, novos palestrantes podem ser inclusos ou por qualquer motivo removidos. 
            </p> 
          </div> 
        </div> 
        <div class='cmddiv hidden' id='palestrante-porcelli'> 
          <div class='line gapTop'> 
            <div class='unit'> 
              &gt;&nbsp;
            </div> 
            <h1 class='lastUnit command'> 
              palestrante porcelli
            </h1> 
          </div> 
          <div class='gapLeft smallGapTop'> 
            <h1 class="sql"> 
              Alexandre Porcelli
            </h1> 
            <p> 
              Possui mais de 14 anos em v&aacute;rios nichos de tecnologia. Especialista no desenvolvimento de parsers para compiladores, conversores, buscas e profiling de fontes desde o bug do mil&ecirc;nio, experi&ecirc;ncia essa que lhe permitiu idealizar a plataforma OpenSpotLight. &Eacute; engajado e atuante na comunidade de Software Livre Internacional sendo commiter de relevantes projetos internacionais.
            </p> 
          </div> 
        </div> 
        <div class='cmddiv hidden' id='palestrante-edgar-silva'> 
          <div class='line gapTop'> 
            <div class='unit'> 
              &gt;&nbsp;
            </div> 
            <h1 class='lastUnit command'> 
              palestrante edgar-silva
            </h1> 
          </div> 
          <div class='gapLeft smallGapTop'> 
            <h1 class="sql"> 
              Edgar Silva
            </h1> 
            <p> 
              Desde 1998 atua com Java e Objetos Distribu&iacute;dos e aplica&ccedil;&otilde;es Web, trabalhou em v&aacute;rios dos mais desafiantes projetos corporativos envolvendo Java no Brasil, entre eles o Novo Loterias da Caixa Economica em 2004, envolvido com Boas Pr&aacute;ticas em Arquiteturas e Desenvolvimento de Componentes de Middleware e Integra&ccedil;&otilde;es de Sistemas/SOA . Um experiente Arquiteto, Consultor e Instrutor, j&aacute;  palestrou em v&aacute;rios eventos  no Brasil e no exterior(JavaOne, JBossWorld, Java.Net Corner nos EUA e Jazoon 2010 em Zurich. Edgar trouxe a pr&aacute;tica de Middleware para a Red Hat Brasil em 2007, e desde ent&atilde;o vem educando o time de vendas, clientes, servi&ccedil;os e marketing a respeito de assuntos e tecnologias de Middleware na filial brasileira.
            </p> 
          </div> 
        </div> 
        <div class='cmddiv hidden' id='palestrante-samuel'> 
          <div class='line gapTop'> 
            <div class='unit'> 
              &gt;&nbsp;
            </div> 
            <h1 class='lastUnit command'> 
              palestrante samuel
            </h1> 
          </div> 
          <div class='gapLeft smallGapTop'> 
            <h1 class="sql"> 
              Samuel Tauil
            </h1> 
            <p> 
              Santista, Formado em Ci&ecirc;ncias de Computa&ccedil;&atilde;o, tendo trabalhado com plataformas Java e Integra&ccedil;&atilde;o em empresas como Buscap&eacute;, Getronics e Atech (Projeto Siga Sa&uacute;de - vencedor do Duke Awards 2005). Trabalha na JBoss,by Red Hat como Instrutor e Consultorias em Arquiteturas e boas pr&aacute;ticas de projetos de tecnologias JBoss, atualmente est&aacute; muito envolvido com projetos de Cloud em especial o projeto Infinispan (antigo JBossCache).
            </p> 
          </div> 
        </div> 
        <div class='cmddiv hidden' id='palestrante-teston'> 
          <div class='line gapTop'> 
            <div class='unit'> 
              &gt;&nbsp;
            </div> 
            <h1 class='lastUnit command'> 
              palestrante teston
            </h1> 
          </div> 
          <div class='gapLeft smallGapTop'> 
            <h1 class="sql"> 
              Luiz Fernando Teston
            </h1> 
            <p> 
              &Eacute; Arquiteto/Desenvolvedor Java com experi&ecirc;ncia tanto na stack JEE padr&atilde;o quanto em desenvolvimento low level Java envolvendo manipula&ccedil;&atilde;o de bytecode em runtime e outras coisas do tipo. F&atilde; de linguagens funcionais como Erlang e Clojure, nos ultimos anos tem utilizado elementos da abordagem funcional para atingir pleno paralelismo em seu c&oacute;digo. Atualmente &eacute; Core Developer do OpenSpotLight e nos ultimos meses tem pesquisado diferentes implementa&ccedil;&otilde;es noSQL para uso em seu atual projeto.
            </p> 
          </div> 
        </div> 
        <div class='cmddiv hidden' id='palestrante-vinicius'> 
          <div class='line gapTop'> 
            <div class='unit'> 
              &gt;&nbsp;
            </div> 
            <h1 class='lastUnit command'> 
              palestrante vinicius
            </h1> 
          </div> 
          <div class='gapLeft smallGapTop'> 
            <h1 class="sql"> 
              Vinicius Carvalho
            </h1> 
            <p> 
              Missing.
            </p> 
          </div> 
        </div> 
        <div class='cmddiv hidden' id='palestrante-guilherme'> 
          <div class='line gapTop'> 
            <div class='unit'> 
              &gt;&nbsp;
            </div> 
            <h1 class='lastUnit command'> 
              palestrante guilherme
            </h1> 
          </div> 
          <div class='gapLeft smallGapTop'> 
            <h1 class="sql"> 
              Guilherme Silveira
            </h1> 
            <p> 
              L&iacute;der t&eacute;cnico da Caelum, graduando em matem&aacute;tica aplicada na USP, ministrou diversas palestras relacionadas ao desenvolvimento na web. Junto com Paulo Silveira, criou o VRaptor em 2003. Atualmente tem o foco na implementa&ccedil;&atilde;o de integra&ccedil;&atilde;o de sistemas atrav&eacute;s de api&#x27;s rest e seu impacto positivo no plano de neg&oacute;cios dos clientes da Caelum e &eacute; commiter de projetos como restfulie, xstream, paranamer e waffle com &ecirc;nfase em Java e Ruby.
            </p> 
          </div> 
        </div> 
        
        
        
                
        
      </div> 
      
      
      <div class='line center smallAir border dim'> 
        <div class='cmddiv alwaysHidden' id='notfound'> 
          
          <div class='line gapTop'> 
            <div class='unit'> 
              &gt;&nbsp;
            </div> 
            <h1 class='lastUnit command'> 
              abc
            </h1> 
          </div>
          
          <div class='gapLeft smallGapTop'> 
            <h2> 
              Command not found.
            </h2> 
          </div> 
          
          
        </div> 

       <div class='line gapTop' id='prompt'> 
          <div class='unit'> 
            &gt;&nbsp;
          </div> 
          <div class='unit command' id='command'></div> 
          <div class='bright unit' id='cursor'> 
            |
          </div> 
        </div> 
       
                
      </div> 
      
      
      <div class='foot smallAirTop bigAirBottom'> 
        <div class='unit size1of2 tag'> 
          <span style='font-size: 0.7em;'><?php print exec("uptime"); ?></span> 
          
        </div> 
        <div class='lastUnit size1of2 tag right'> 
          <span class='dim'>2010 &copy;</span> <a class='link' href='http://www.adell.no/' target="_blank">Adell Group</a> 
        </div> 
      </div> 
    </div> 
    
    <script src='http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js' type='text/javascript'></script> 
    <script src="nosql.js" type='text/javascript'></script> 
    
  </body> 
</html> 
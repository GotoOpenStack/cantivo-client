﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using NUnit.Framework;

namespace Adell.ItCan.Interop.Tests
{
    [TestFixture]
    class UrlTest
    {
        [Test]
         public void Test()
        {
            //var correct = "http://127.0.0.1:8080/api/?key=YWRtaW46MjEyMzJmMjk3YTU3YTVhNzQzODk0YTBlNGE4MDFmYzM=";
            //var url = ITCLib.Services.HttpHostListService.GetUrl(
            //    new NetworkCredential("admin", "admin"), 
            //    new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8080));
            //Console.WriteLine(correct);
            //Console.WriteLine(url);

            //Assert.That(Is.Equals(url, correct));
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;

namespace ITCLib.Services
{
    public class StatusReportService
    {
        public StatusReportService(IPEndPoint ep)
        {
            
        }

        public void ReportAlive()
        {
            
        }

        public void ReportConnected()
        {
            
        }

        public void ReportDisconnected()
        {
            
        }


    }
}

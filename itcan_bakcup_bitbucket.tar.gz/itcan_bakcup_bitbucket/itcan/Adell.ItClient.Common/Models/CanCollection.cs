﻿using System.Collections.ObjectModel;

namespace Adell.ItClient.Common.Models
{
    public class CanCollection : Collection<Can>
    {
    }
}

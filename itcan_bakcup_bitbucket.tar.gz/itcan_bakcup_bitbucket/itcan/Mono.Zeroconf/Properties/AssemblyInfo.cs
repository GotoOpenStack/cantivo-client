using System.Reflection;
using System.Runtime.CompilerServices;

[assembly:AssemblyVersion("4.0.0.90")]
[assembly:AssemblyTitle("Mono.Zeroconf")]
[assembly:AssemblyDescription("Cross Platform Zeroconf for .NET")]
[assembly:AssemblyCopyright("Copyright (C) 2006-2009 Novell, Inc.")]
[assembly:AssemblyCompany("Novell, Inc.")]

